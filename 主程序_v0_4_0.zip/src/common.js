'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(path.resolve(ROOT, filePath), 'utf8'));
}
function writeJson(filePath, value) {
  const full = path.resolve(ROOT, filePath);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, JSON.stringify(value, null, 2) + '\n', 'utf8');
}
function ensureDir(dir) { fs.mkdirSync(dir, { recursive: true }); }
function escapeXml(value) {
  return String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function safeId(value) { return String(value).replace(/[^A-Za-z0-9_.:-]+/g, '-'); }
function fmt(value) { return Number(value.toFixed(5)).toString(); }
function parseAttributes(raw) {
  const attrs = {};
  const re = /([A-Za-z_][\w:.-]*)\s*=\s*"([^"]*)"/g;
  let m;
  while ((m = re.exec(raw)) !== null) attrs[m[1]] = m[2];
  return attrs;
}
function parseStyle(style) {
  const out = {};
  for (const part of String(style || '').split(';')) {
    const i = part.indexOf(':');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    const v = part.slice(i + 1).trim();
    if (k) out[k] = v;
  }
  return out;
}
function serializeStyle(styleMap) {
  return Object.entries(styleMap).map(([k, v]) => `${k}:${v}`).join(';');
}
function parseMatrix(transform, pathId) {
  const m = String(transform || '').match(/matrix\(\s*([^)]*)\s*\)/);
  if (!m) throw new Error(`路径 ${pathId} 没有 matrix() 变换；本项目针对当前无底.svg 的矩阵格式，停止以避免错位。`);
  const nums = m[1].split(/[\s,]+/).filter(Boolean).map(Number);
  if (nums.length !== 6 || !nums.every(Number.isFinite)) throw new Error(`路径 ${pathId} 的 matrix() 无效。`);
  return nums;
}

// Conservative SVG path bounds parser. It includes Bézier control points (a safe over-bound),
// adequate for component grouping/centering. Original path data is always preserved verbatim.
function pathBounds(d) {
  const tokens = String(d).match(/[-+]?(?:\d*\.\d+|\d+\.?\d*)(?:[eE][-+]?\d+)?|[a-zA-Z]/g) || [];
  let i = 0, cmd = null;
  let x = 0, y = 0, sx = 0, sy = 0;
  const pts = [];
  const isCmd = t => /^[a-zA-Z]$/.test(t || '');
  const hasNum = () => i < tokens.length && !isCmd(tokens[i]);
  const num = () => {
    if (!hasNum()) throw new Error(`SVG path 数据不完整：${d.slice(0, 90)}`);
    const n = Number(tokens[i++]);
    if (!Number.isFinite(n)) throw new Error('SVG path 含非数值坐标。');
    return n;
  };
  const add = (px, py) => { pts.push([px, py]); };
  let guard = 0;
  while (i < tokens.length) {
    if (++guard > 100000) throw new Error('SVG path 解析保护触发。');
    if (isCmd(tokens[i])) {
      cmd = tokens[i++];
      if (cmd === 'Z' || cmd === 'z') { x = sx; y = sy; add(x, y); cmd = null; continue; }
    }
    if (!cmd) continue;
    const upper = cmd.toUpperCase();
    const rel = cmd !== upper;
    if (upper === 'M' || upper === 'L' || upper === 'T') {
      let first = true;
      while (hasNum()) {
        const a = num(), b = num();
        x = rel ? x + a : a; y = rel ? y + b : b;
        add(x, y);
        if (upper === 'M' && first) { sx = x; sy = y; first = false; cmd = rel ? 'l' : 'L'; }
      }
    } else if (upper === 'H') {
      while (hasNum()) { const a = num(); x = rel ? x + a : a; add(x, y); }
    } else if (upper === 'V') {
      while (hasNum()) { const a = num(); y = rel ? y + a : a; add(x, y); }
    } else if (upper === 'C') {
      while (hasNum()) {
        const ox = x, oy = y;
        const a=num(),b=num(),c=num(),e=num(),f=num(),g=num();
        const p1 = rel ? [ox+a,oy+b] : [a,b];
        const p2 = rel ? [ox+c,oy+e] : [c,e];
        const p3 = rel ? [ox+f,oy+g] : [f,g];
        add(...p1); add(...p2); add(...p3); [x,y]=p3;
      }
    } else if (upper === 'S' || upper === 'Q') {
      while (hasNum()) {
        const ox=x, oy=y;
        const a=num(),b=num(),c=num(),e=num();
        const p1=rel?[ox+a,oy+b]:[a,b]; const p2=rel?[ox+c,oy+e]:[c,e];
        add(...p1); add(...p2); [x,y]=p2;
      }
    } else if (upper === 'A') {
      while (hasNum()) {
        const rx=num(), ry=num(); num(); num(); num();
        const ex=num(), ey=num();
        const nx=rel?x+ex:ex, ny=rel?y+ey:ey;
        add(x-rx,y-ry); add(x+rx,y+ry); add(nx-rx,ny-ry); add(nx+rx,ny+ry); add(nx,ny); x=nx; y=ny;
      }
    } else {
      throw new Error(`暂不支持路径命令 ${cmd}。原始 SVG 未修改，请把该路径交由人工检查。`);
    }
  }
  if (!pts.length) return null;
  const xs=pts.map(p=>p[0]), ys=pts.map(p=>p[1]);
  return { minX:Math.min(...xs), minY:Math.min(...ys), maxX:Math.max(...xs), maxY:Math.max(...ys) };
}
function transformBounds(bounds, matrix, page) {
  const [a,b,c,d,e,f] = matrix;
  const raw = [
    [bounds.minX,bounds.minY],[bounds.maxX,bounds.minY],
    [bounds.minX,bounds.maxY],[bounds.maxX,bounds.maxY]
  ].map(([x,y]) => [a*x+c*y+e-page.x, b*x+d*y+f-page.y]);
  const xs=raw.map(p=>p[0]), ys=raw.map(p=>p[1]);
  const minX=Math.min(...xs), maxX=Math.max(...xs), minY=Math.min(...ys), maxY=Math.max(...ys);
  return {x:minX,y:minY,width:maxX-minX,height:maxY-minY,cx:(minX+maxX)/2,cy:(minY+maxY)/2};
}
function getTileMeta(pageNumber, manifest) {
  for (const group of manifest.groups) {
    const idx = group.pages.indexOf(pageNumber);
    if (idx >= 0) {
      const number = group.start_number + idx;
      return { tile_id:`${group.prefix}-${String(number).padStart(2,'0')}`, category:group.category,
        category_title:group.title, display_name:`${group.title} ${String(number).padStart(2,'0')}`,
        number, page:pageNumber };
    }
  }
  return {tile_id:`page-${String(pageNumber).padStart(2,'0')}`,category:'unclassified',category_title:'未分类',display_name:`Source page ${pageNumber}`,number:pageNumber,page:pageNumber};
}
function clusterByCenter(items, tolerance) {
  const clusters=[];
  for (const item of items) {
    let best=null, bestD=Infinity;
    for (const cluster of clusters) {
      const cx=cluster.reduce((a,p)=>a+p.bounds.cx,0)/cluster.length;
      const cy=cluster.reduce((a,p)=>a+p.bounds.cy,0)/cluster.length;
      const d=Math.hypot(item.bounds.cx-cx,item.bounds.cy-cy);
      if (d<bestD) { bestD=d; best=cluster; }
    }
    if (best && bestD<=tolerance) best.push(item); else clusters.push([item]);
  }
  return clusters;
}

module.exports = { ROOT, readJson, writeJson, ensureDir, escapeXml, safeId, fmt,
  parseAttributes, parseStyle, serializeStyle, parseMatrix, pathBounds, transformBounds,
  getTileMeta, clusterByCenter };
