'use strict';

const fs = require('fs');
const path = require('path');
const { ROOT, readJson, writeJson } = require('./common');
const { VERSION, applyDesignModel } = require('./design_model');

function main() {
  const settings = readJson('settings.json');
  const relative = settings.library_file || 'library/asset_library.json';
  const file = path.resolve(ROOT, relative);
  if (!fs.existsSync(file)) throw new Error(`找不到资产库：${relative}`);
  const library = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (library.schema_version === VERSION && library.design_model_version === VERSION) {
    console.log(`资产库已经是 v${VERSION}，无需迁移。`);
    return;
  }
  const backup = `${file}.pre-v${VERSION}.bak`;
  if (!fs.existsSync(backup)) fs.copyFileSync(file, backup);
  const migrated = applyDesignModel(library, settings);
  writeJson(relative, migrated);
  console.log(`资产库已升级至 v${VERSION}。`);
  console.log(`  原始备份：${path.relative(ROOT, backup)}`);
  console.log(`  42张牌 · ${migrated.component_families.length}个视觉组件家族`);
  console.log(`  单角标：27张数字牌 + 4张风牌 + 8张花牌`);
  console.log('  龙牌没有角标；白龙/Soap 保留原矩形标记。');
}

if (require.main === module) {
  try { main(); } catch (err) { console.error(`\n资产库升级失败：${err.stack || err.message}`); process.exitCode = 1; }
}
module.exports = { main };
