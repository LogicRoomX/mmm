'use strict';
const fs = require('fs');
const path = require('path');
const { ROOT, readJson } = require('./common');

function walk(node, out = { paths: [], groups: [], texts: [] }) {
  if (node.kind === 'path') out.paths.push(node);
  else if (node.kind === 'text') out.texts.push(node);
  else if (node.kind === 'group') {
    out.groups.push(node);
    for (const c of node.children || []) walk(c, out);
  }
  return out;
}
function main() {
  const settings = readJson('settings.json');
  const libFile = path.resolve(ROOT, settings.library_file || 'library/asset_library.json');
  if (!fs.existsSync(libFile)) throw new Error('资产库不存在；请先执行首次吸收。');
  const lib = JSON.parse(fs.readFileSync(libFile, 'utf8'));
  const errors = [];
  if (lib.schema !== 'american-mahjong-asset-library') errors.push('schema 错误');
  if (lib.schema_version !== '0.4.0' || lib.design_model_version !== '0.4.0') errors.push('设计模型版本不是 v0.4.0；请运行 02_RENDER_FROM_LIBRARY.bat 自动升级。');
  if (lib.tiles?.length !== 42) errors.push(`现有牌面数不是42：${lib.tiles?.length}`);
  if (lib.path_index?.length !== 384) errors.push(`原始路径索引数不是384：${lib.path_index?.length}`);
  if (lib.source?.runtime_source_dependency !== false) errors.push('资产库仍声明依赖源 SVG');

  const ids = new Set((lib.component_definitions || []).map(x => x.component_id));
  const sourceIds = new Set();
  let pathTotal = 0, outlineTotal = 0, legacyTotal = 0, indexGroups = 0, textMarks = 0, flowerLabels = 0;
  const counts = { dotPips: 0, bambooUpright: 0, bambooChevrons: 0, wan: 0, flowers: 0 };
  for (const tile of lib.tiles || []) {
    const flat = walk(tile.root);
    pathTotal += flat.paths.length;
    const outlines = flat.paths.filter(p => p.role === 'tile-outline');
    outlineTotal += outlines.length;
    if (outlines.length !== 1) errors.push(`${tile.tile_id} 外轮廓数量不是1`);
    for (const p of flat.paths) {
      if (!ids.has(p.component_id)) errors.push(`${tile.tile_id}/${p.source_id} 缺少几何组件`);
      if (sourceIds.has(p.source_id)) errors.push(`源路径 ID 重复：${p.source_id}`);
      sourceIds.add(p.source_id);
    }
    const markerGroup = flat.groups.find(g => g.id === 'legacy-index-marker');
    const legacy = flat.paths.filter(p => p.role === 'legacy-flower-index');
    legacyTotal += legacy.length;
    if (tile.category === 'flowers' && legacy.length && (!markerGroup || markerGroup.visible !== false)) errors.push(`${tile.tile_id} 的旧序号没有隐藏归档`);

    const markGroup = flat.groups.find(g => g.id === 'tile-index-mark');
    if (markGroup) {
      indexGroups++;
      textMarks += flat.texts.filter(t => t.role === 'tile-index-mark').length;
      if (markGroup.children?.length !== 1 || markGroup.children[0].kind !== 'text') errors.push(`${tile.tile_id} 角标结构不正确`);
    }
    if (['dots', 'bams', 'craks'].includes(tile.category) && !markGroup) errors.push(`${tile.tile_id} 缺少单数字角标`);
    if (tile.category === 'winds' && (!markGroup || !['E', 'S', 'W', 'N'].includes(markGroup.semantic_value))) errors.push(`${tile.tile_id} 风牌角标缺失或错误`);
    if (tile.category === 'dragons' && markGroup) errors.push(`${tile.tile_id} 龙牌不应有角标`);
    if (tile.category === 'flowers' && (!markGroup || !['1', '2', '3', '4'].includes(markGroup.semantic_value))) errors.push(`${tile.tile_id} 花牌数字角标缺失或错误`);

    if (tile.category === 'dots' && tile.number > 1) {
      const arr = flat.groups.find(g => g.id === 'dot-arrangement');
      for (const g of arr?.children || []) {
        if (g.visual_component_id !== 'dot-pip' || g.component_type !== 'dot-pip-instance' || g.children?.length !== 3) errors.push(`${tile.tile_id}/${g.id} 不是完整三层筒点组件`);
        counts.dotPips++;
      }
    }
    if (tile.category === 'bams' && tile.number > 1) {
      for (const g of flat.groups) {
        if (g.visual_component_id === 'bamboo-upright') counts.bambooUpright++;
        if (g.visual_component_id === 'bamboo-chevron') counts.bambooChevrons++;
      }
    }
    if (tile.category === 'craks' && flat.groups.some(g => g.visual_component_id === 'wan-symbol')) counts.wan++;
    if (tile.category === 'flowers') {
      const labels = flat.groups.filter(g => g.id === 'flower-name-label');
      if (labels.length !== 1 || !flat.texts.some(t => t.role === 'flower-name-label')) errors.push(`${tile.tile_id} 缺少花牌系列名称标签`);
      flowerLabels += labels.length;
      const art = flat.groups.filter(g => g.id === 'flower-artwork');
      if (art.length !== 1) errors.push(`${tile.tile_id} 必须只有一个完整 flower-artwork 组件`);
      if (art[0] && art[0].children?.some(c => c.kind === 'group')) errors.push(`${tile.tile_id} 花牌图案仍存在内部子组`);
      counts.flowers += art.length;
    }
  }
  if (pathTotal !== 384) errors.push(`树内路径总数错误：${pathTotal}`);
  if (outlineTotal !== 42) errors.push(`外框总数错误：${outlineTotal}`);
  if (legacyTotal !== 8) errors.push(`花牌旧序号应归档8条，实际 ${legacyTotal}`);
  if (indexGroups !== 39) errors.push(`应有39个单角标组，实际 ${indexGroups}`);
  if (textMarks !== 39) errors.push(`应有39个数字/风牌角标文本，实际 ${textMarks}`);
  if (flowerLabels !== 8) errors.push(`应有8个花牌名称标签，实际 ${flowerLabels}`);
  if (counts.dotPips !== 44) errors.push(`2-9筒应有44颗筒点，实际 ${counts.dotPips}`);
  if (counts.bambooUpright !== 40) errors.push(`2-9索应有40根直立竹，实际 ${counts.bambooUpright}`);
  if (counts.bambooChevrons !== 2) errors.push(`8索应有2组V形竹，实际 ${counts.bambooChevrons}`);
  if (counts.wan !== 9) errors.push(`应有9个萬字组件实例，实际 ${counts.wan}`);
  if (counts.flowers !== 8) errors.push(`应有8个完整花牌图案组，实际 ${counts.flowers}`);
  if (lib.asset_completeness?.joker_artwork_present !== false) errors.push('Joker缺失状态没有正确登记');
  if (lib.asset_completeness?.dragons_with_corner_marks !== 0) errors.push('龙牌角标策略应为0');

  if (errors.length) {
    console.error('验证失败：'); errors.forEach(x => console.error(' - ' + x)); process.exitCode = 1; return;
  }
  console.log('v0.4.0 资产库验证通过：');
  console.log(`  42 张现有牌 · ${pathTotal} 条源路径实例 · ${ids.size} 个几何定义`);
  console.log(`  ${outlineTotal} 个独立牌框 · ${legacyTotal} 条旧花牌序号隐藏归档`);
  console.log(`  角标：27张数字牌 + 4张风牌 + 8张花牌 = ${indexGroups} 个；龙牌0个`);
  console.log(`  花牌名称标签：${flowerLabels}个（四季缩写 + 四君子英文名）`);
  console.log(`  组件：${counts.dotPips}颗筒点 · ${counts.bambooUpright}根直立竹 · ${counts.bambooChevrons}组V形竹 · ${counts.wan}个萬字 · ${counts.flowers}张整体花牌`);
  console.log('  White Dragon/Soap 保留；Red/Green Dragon、4张福禄寿贵和 Joker 仍待素材补齐。');
  console.log('  运行时仅使用 asset_library.json，不依赖原始 SVG。');
}
if (require.main === module) { try { main(); } catch (e) { console.error('验证失败：' + (e.stack || e.message)); process.exitCode = 1; } }
module.exports = { walk };
