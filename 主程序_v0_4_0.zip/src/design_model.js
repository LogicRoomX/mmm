'use strict';

/**
 * American Mahjong semantic design model v0.4.0.
 * Keeps source geometry untouched while grouping complete visual units and
 * adding semantic index marks. The original 384 path instances remain intact.
 */

const { pathBounds } = require('./common');

const VERSION = '0.4.0';
const WIND_OFFSETS = {
  'wind-01': 56.31, // East
  'wind-02': 35.19, // South
  'wind-03': 31.08, // West
  'wind-04': 37.62  // North
};
const FLOWER_META = {
  'flower-01': { name: 'Summer', label: 'SUM', season: 'summer', series: 'seasons', number: 2, side: 'left', display_order: 2, color: '#2926a5' },
  'flower-02': { name: 'Spring', label: 'SPR', season: 'spring', series: 'seasons', number: 1, side: 'left', display_order: 1, color: '#2926a5' },
  'flower-03': { name: 'Autumn', label: 'AUT', season: 'autumn', series: 'seasons', number: 3, side: 'left', display_order: 3, color: '#2926a5' },
  'flower-04': { name: 'Winter', label: 'WIN', season: 'winter', series: 'seasons', number: 4, side: 'left', display_order: 4, color: '#2926a5' },
  'flower-05': { name: 'Bamboo', label: 'BAMBOO', season: null, series: 'four-gentlemen', number: 3, side: 'right', display_order: 7, color: '#d11228' },
  'flower-06': { name: 'Orchid', label: 'ORCHID', season: null, series: 'four-gentlemen', number: 2, side: 'right', display_order: 6, color: '#d11228' },
  'flower-07': { name: 'Chrysanthemum', label: 'CHRYSANTHEMUM', season: null, series: 'four-gentlemen', number: 4, side: 'right', display_order: 8, color: '#d11228' },
  'flower-08': { name: 'Plum', label: 'PLUM', season: null, series: 'four-gentlemen', number: 1, side: 'right', display_order: 5, color: '#d11228' }
};
const WIND_LABELS = { 'wind-01': 'E', 'wind-02': 'S', 'wind-03': 'W', 'wind-04': 'N' };
const SUIT_COLORS = { dots: '#1f489b', bams: '#21983a', craks: '#d11228', winds: '#2926a5' };

function makeGroup(id, componentType, children, extra = {}) {
  return {
    kind: 'group', id, component_type: componentType, visible: extra.visible !== false,
    layout_transform: extra.layout_transform || null,
    children,
    ...Object.fromEntries(Object.entries(extra).filter(([k]) => !['visible', 'layout_transform'].includes(k)))
  };
}
function walk(node, fn) {
  fn(node);
  for (const child of node.children || []) walk(child, fn);
}
function findGroup(node, id) {
  if (!node) return null;
  if (node.kind === 'group' && node.id === id) return node;
  for (const child of node.children || []) {
    const found = findGroup(child, id);
    if (found) return found;
  }
  return null;
}
function collectPaths(node, out = []) {
  if (!node) return out;
  if (node.kind === 'path') out.push(node);
  for (const child of node.children || []) collectPaths(child, out);
  return out;
}
function unionBounds(nodes) {
  const bs = nodes.map(n => n.bounds).filter(Boolean);
  if (!bs.length) return null;
  const x = Math.min(...bs.map(b => b.x));
  const y = Math.min(...bs.map(b => b.y));
  const right = Math.max(...bs.map(b => b.x + b.width));
  const bottom = Math.max(...bs.map(b => b.y + b.height));
  return { x, y, width: right - x, height: bottom - y, cx: (x + right) / 2, cy: (y + bottom) / 2 };
}
function colorKey(color) {
  const c = String(color || '').toLowerCase();
  if (c === '#21983a' || c === '#39ae36' || c === '#b3d796') return 'green';
  if (c === '#1f489b' || c === '#1a449a' || c === '#2f6eb6') return 'blue';
  if (c === '#d11228' || c === '#e51e28') return 'red';
  return 'other';
}
function textNode(id, text, x, y, options = {}) {
  return {
    kind: 'text', id, role: options.role || 'tile-index-mark', text: String(text),
    x, y, fill: options.fill || '#292723',
    font_family: options.font_family || 'Arial, Helvetica, sans-serif',
    font_size: options.font_size || 78,
    font_weight: options.font_weight || 700,
    text_anchor: options.text_anchor || 'start',
    dominant_baseline: 'alphabetic'
  };
}
function makeIndexGroup(tile, text, position, fill, settings) {
  const cfg = settings.index_marks || {};
  if (cfg.enabled === false) return null;
  const isRight = position === 'top-right';
  const x = isRight ? Number(cfg.right_x || 965) : Number(cfg.left_x || 168);
  const y = Number(cfg.baseline_y || 258);
  const size = Number(cfg.font_size || 78);
  const node = textNode(`index-${tile.tile_id}`, text, x, y, {
    fill, font_size: size, font_weight: cfg.font_weight || 700,
    font_family: cfg.font_family || 'Arial, Helvetica, sans-serif',
    text_anchor: isRight ? 'end' : 'start'
  });
  return makeGroup('tile-index-mark', 'tile-index-mark', [node], {
    placement: position, semantic_value: String(text), generated_by: 'design-model-v0.4.0'
  });
}
function makeFlowerNameGroup(tile, meta, settings) {
  const cfg = settings.index_marks || {};
  if (cfg.enabled === false) return null;
  const labelSide = meta.side === 'left' ? 'top-right' : 'top-left';
  const isRight = labelSide === 'top-right';
  const x = isRight ? Number(cfg.right_x || 965) : Number(cfg.left_x || 168);
  const y = Number(cfg.baseline_y || 258);
  const size = meta.series === 'seasons' ? 52 : (meta.label.length > 10 ? 48 : 50);
  const node = textNode(`flower-name-${tile.tile_id}`, meta.label, x, y, {
    role: 'flower-name-label', fill: meta.color, font_size: size,
    font_weight: 600, font_family: cfg.font_family || 'Arial, Helvetica, sans-serif',
    text_anchor: isRight ? 'end' : 'start'
  });
  return makeGroup('flower-name-label', 'flower-name-label', [node], {
    placement: labelSide, semantic_value: meta.label, generated_by: 'design-model-v0.4.0'
  });
}

function annotateGroup(group, visualId, parameters = {}) {
  if (!group) return;
  group.visual_component_id = visualId;
  group.component_parameters = parameters;
}
function flattenGroup(group, newId, type, visualId, parameters = {}) {
  const paths = collectPaths(group);
  return makeGroup(newId, type, paths, {
    layout_transform: group.layout_transform || null,
    layout_key: group.layout_key || null,
    bounds: unionBounds(paths),
    visual_component_id: visualId,
    component_parameters: parameters
  });
}

function rebindToPrototype(pathNode, prototypeDefinition, familyId) {
  if (!pathNode || !prototypeDefinition || !pathNode.bounds) return;
  const local = pathBounds(prototypeDefinition.d);
  if (!local) throw new Error(`组件原型 ${prototypeDefinition.component_id} 无法计算边界。`);
  const w = Math.max(1e-9, local.maxX - local.minX);
  const h = Math.max(1e-9, local.maxY - local.minY);
  const target = pathNode.bounds;
  const sx = target.width / w;
  const sy = target.height / h;
  if (!pathNode.original_component_id) pathNode.original_component_id = pathNode.component_id;
  if (!pathNode.original_matrix) pathNode.original_matrix = pathNode.matrix.slice();
  // Preserve the source instance's axis orientation (the supplied SVG uses a Y flip).
  const signX = Math.sign(pathNode.original_matrix[0] || 1) || 1;
  const signY = Math.sign(pathNode.original_matrix[3] || 1) || 1;
  const tx = signX > 0 ? target.x - sx * local.minX : target.x + sx * local.maxX;
  const ty = signY > 0 ? target.y - sy * local.minY : target.y + sy * local.maxY;
  pathNode.component_id = prototypeDefinition.component_id;
  pathNode.matrix = [signX * sx, 0, 0, signY * sy, tx, ty];
  pathNode.geometry_reuse_family = familyId;
}
function updatePathIndex(library) {
  const bySource = new Map();
  for (const tile of library.tiles || []) {
    walk(tile.root, node => {
      if (node.kind === 'path' && node.geometry_reuse_family) bySource.set(node.source_id, node);
    });
  }
  for (const item of library.path_index || []) {
    const node = bySource.get(item.source_path_id);
    if (!node) continue;
    if (!item.original_component_id) item.original_component_id = item.component_id;
    item.component_id = node.component_id;
    item.geometry_reuse_family = node.geometry_reuse_family;
    item.normalized_matrix = node.matrix.slice();
  }
}
function normalizeSharedGeometry(library) {
  const defs = new Map((library.component_definitions || []).map(d => [d.component_id, d]));
  const dotFour = (library.tiles || []).find(t => t.tile_id === 'dot-04');
  const dotFourPip = dotFour && findGroup(dotFour.root, 'pip-01');
  const pipPrototypes = dotFourPip ? collectPaths(dotFourPip).map(p => defs.get(p.component_id)).filter(Boolean) : [];
  const bamTwo = (library.tiles || []).find(t => t.tile_id === 'bam-02');
  const bamTwoArrangement = bamTwo && findGroup(bamTwo.root, 'bamboo-arrangement');
  const bambooPrototypePath = bamTwoArrangement && bamTwoArrangement.children?.[0] && collectPaths(bamTwoArrangement.children[0])[0];
  const bambooPrototype = bambooPrototypePath && defs.get(bambooPrototypePath.component_id);
  const crakOne = (library.tiles || []).find(t => t.tile_id === 'crak-01');
  const wanGroup = crakOne && findGroup(crakOne.root, 'wan-symbol');
  const wanPath = wanGroup && collectPaths(wanGroup)[0];
  const wanPrototype = wanPath && defs.get(wanPath.component_id);

  if (pipPrototypes.length !== 3 || !bambooPrototype || !wanPrototype) {
    throw new Error('无法建立筒点、直立竹或萬字的共享几何原型；请检查原始资产库。');
  }
  const counts = { pipPaths: 0, bambooPaths: 0, wanPaths: 0 };
  for (const tile of library.tiles || []) {
    if (tile.category === 'dots' && tile.number > 1) {
      const arrangement = findGroup(tile.root, 'dot-arrangement');
      for (const pip of arrangement?.children || []) {
        const paths = collectPaths(pip);
        if (paths.length !== 3) throw new Error(`${tile.tile_id}/${pip.id} 不是3条路径的同心筒点。`);
        paths.forEach((p, i) => { rebindToPrototype(p, pipPrototypes[i], 'dot-pip'); counts.pipPaths++; });
      }
    }
    if (tile.category === 'bams' && tile.number > 1) {
      const arrangement = findGroup(tile.root, 'bamboo-arrangement');
      for (const stick of arrangement?.children || []) {
        const p = collectPaths(stick)[0];
        if (p && p.bounds && p.bounds.height >= p.bounds.width) {
          rebindToPrototype(p, bambooPrototype, 'bamboo-upright');
          counts.bambooPaths++;
        }
      }
    }
    if (tile.category === 'craks') {
      const wan = findGroup(tile.root, 'wan-symbol');
      const p = wan && collectPaths(wan)[0];
      if (p) { rebindToPrototype(p, wanPrototype, 'wan-symbol'); counts.wanPaths++; }
    }
  }
  updatePathIndex(library);
  return { ...counts, prototype_ids: {
    dot_pip: pipPrototypes.map(p => p.component_id),
    bamboo_upright: bambooPrototype.component_id,
    wan_symbol: wanPrototype.component_id
  }};
}

function assignBambooFamilies(tile, arrangement) {
  if (!arrangement) return { upright: 0, chevrons: 0 };
  const original = arrangement.children || [];
  if (tile.tile_id !== 'bam-08') {
    for (const stick of original) {
      const p = collectPaths(stick)[0];
      const b = unionBounds([p]);
      const compact = b && b.height / Math.max(1, b.width) < 2.9;
      stick.id = stick.id.replace(/^bamboo-stick-/, 'bamboo-upright-');
      stick.component_type = 'bamboo-upright-stick';
      stick.bounds = b;
      annotateGroup(stick, 'bamboo-upright', {
        color_key: colorKey(p && p.fill),
        size_variant: compact ? 'compact' : 'standard',
        width: b ? b.width : null, height: b ? b.height : null,
        editable_unit: 'one-complete-upright-bamboo'
      });
    }
    return { upright: original.length, chevrons: 0 };
  }

  const vertical = [], horizontal = [];
  for (const stick of original) {
    const p = collectPaths(stick)[0];
    const b = unionBounds([p]);
    if (b && b.height >= b.width) vertical.push({ stick, p, bounds: b });
    else horizontal.push({ stick, p, bounds: b });
  }
  for (const [i, item] of vertical.entries()) {
    item.stick.id = `bamboo-upright-${String(i + 1).padStart(2, '0')}`;
    item.stick.component_type = 'bamboo-upright-stick';
    item.stick.bounds = item.bounds;
    annotateGroup(item.stick, 'bamboo-upright', {
      color_key: colorKey(item.p.fill), size_variant: 'standard',
      width: item.bounds.width, height: item.bounds.height,
      editable_unit: 'one-complete-upright-bamboo'
    });
  }
  horizontal.sort((a, b) => a.bounds.cy - b.bounds.cy);
  const top = horizontal.slice(0, 2);
  const bottom = horizontal.slice(2, 4);
  const motifs = [];
  if (top.length) {
    const paths = top.flatMap(x => collectPaths(x.stick));
    motifs.push(makeGroup('bamboo-chevron-upper', 'bamboo-chevron', paths, {
      bounds: unionBounds(paths), visual_component_id: 'bamboo-chevron',
      component_parameters: { direction: 'upper', color_key: 'green', editable_unit: 'complete-chevron-motif' }
    }));
  }
  if (bottom.length) {
    const paths = bottom.flatMap(x => collectPaths(x.stick));
    motifs.push(makeGroup('bamboo-chevron-lower', 'bamboo-chevron', paths, {
      bounds: unionBounds(paths), visual_component_id: 'bamboo-chevron',
      component_parameters: { direction: 'lower', color_key: 'green', editable_unit: 'complete-chevron-motif' }
    }));
  }
  arrangement.children = [...vertical.map(x => x.stick), ...motifs];
  return { upright: vertical.length, chevrons: motifs.length };
}

function applyDesignModel(library, settings = {}) {
  if (!library || library.schema !== 'american-mahjong-asset-library') throw new Error('不是有效的 American Mahjong 资产库。');
  if (library.schema_version === VERSION && library.design_model_version === VERSION) return library;

  const stats = {
    indexed_number_tiles: 0, indexed_winds: 0, indexed_flowers: 0,
    dot_pips: 0, upright_bamboo: 0, bamboo_chevrons: 0,
    wan_symbols: 0, rank_glyphs: 0, flower_artwork_groups: 0
  };
  const geometryReuse = normalizeSharedGeometry(library);

  for (const tile of library.tiles || []) {
    const content = findGroup(tile.root, 'tile-content');
    if (!content) throw new Error(`${tile.tile_id} 缺少 tile-content。`);
    let mark = null;
    tile.design = tile.design || {};

    if (['dots', 'bams', 'craks'].includes(tile.category)) {
      mark = makeIndexGroup(tile, tile.number, 'top-left', SUIT_COLORS[tile.category], settings);
      stats.indexed_number_tiles++;
    } else if (tile.category === 'winds') {
      const glyph = findGroup(tile.root, 'wind-glyph');
      const dx = WIND_OFFSETS[tile.tile_id];
      if (glyph && Number.isFinite(dx)) {
        glyph.layout_transform = { type: 'translate', x: dx, y: 0 };
        glyph.layout_key = 'wind-optical-centering';
        glyph.bounds = unionBounds(collectPaths(glyph));
        annotateGroup(glyph, 'wind-glyph', { wind: WIND_LABELS[tile.tile_id], editable_unit: 'whole-wind-glyph' });
      }
      mark = makeIndexGroup(tile, WIND_LABELS[tile.tile_id], 'top-left', SUIT_COLORS.winds, settings);
      tile.design.wind = WIND_LABELS[tile.tile_id];
      stats.indexed_winds++;
    } else if (tile.category === 'flowers') {
      const meta = FLOWER_META[tile.tile_id];
      if (!meta) throw new Error(`缺少 ${tile.tile_id} 的花牌语义映射。`);
      const existing = content.children || [];
      const legacy = existing.find(g => g.id === 'legacy-index-marker');
      const botanical = existing.find(g => g.id === 'botanical-composition');
      const retained = existing.filter(g => g !== botanical);
      if (botanical) {
        const artwork = flattenGroup(botanical, 'flower-artwork', 'flower-artwork', 'flower-artwork', {
          name: meta.name, series: meta.series, editable_unit: 'whole-flower-artwork'
        });
        retained.push(artwork);
        stats.flower_artwork_groups++;
      }
      content.children = retained;
      // Seasonal series: number at the left. Four Gentlemen series: number at the right.
      mark = makeIndexGroup(tile, meta.number, meta.side === 'right' ? 'top-right' : 'top-left', meta.color, settings);
      tile.design = {
        ...tile.design,
        common_name: meta.name,
        label_text: meta.label,
        label_position: meta.side === 'left' ? 'top-right' : 'top-left',
        flower_series: meta.series,
        series_number: meta.number,
        display_order: meta.display_order,
        index_mark_position: meta.side === 'right' ? 'top-right' : 'top-left',
        old_source_index: true,
        legacy_index_preserved_hidden: !!legacy
      };
      stats.indexed_flowers++;
    } else if (tile.category === 'dragons') {
      const old = content.children || [];
      const dragon = old.find(g => ['white-dragon-mark', 'red-dragon-glyph', 'green-dragon-glyph'].includes(g.component_type));
      if (dragon) {
        const ref = tile.tile_id === 'dragon-01' ? 'dragon-white-soap' : tile.tile_id === 'dragon-02' ? 'dragon-red-placeholder' : 'dragon-green-placeholder';
        const flattened = flattenGroup(dragon, `${ref}-artwork`, 'dragon-artwork', ref, {
          editable_unit: 'whole-dragon-artwork', source_artwork_status: tile.tile_id === 'dragon-01' ? 'accepted-base' : 'replacement-needed'
        });
        content.children = old.filter(g => g !== dragon).concat(flattened);
      }
      if (tile.tile_id === 'dragon-01') {
        tile.design = { ...tile.design, dragon_type: 'white-dragon-soap', display_name: 'White Dragon / Soap', corner_mark: null, asset_status: 'accepted-base' };
      } else {
        tile.design = { ...tile.design, dragon_type: tile.tile_id === 'dragon-02' ? 'red-dragon' : 'green-dragon', corner_mark: null, asset_status: 'replace-with-american-style-svg' };
      }
    }

    if (tile.category === 'dots') {
      if (tile.number === 1) {
        const old = content.children.find(g => g.id === 'dot-one-medallion');
        if (old) {
          const flat = flattenGroup(old, 'dot-one-artwork', 'dot-one-artwork', 'dot-one-medallion', { editable_unit: 'whole-medallion' });
          content.children = content.children.map(g => g === old ? flat : g);
        }
      } else {
        const arrangement = findGroup(tile.root, 'dot-arrangement');
        for (const pip of arrangement?.children || []) {
          const paths = collectPaths(pip);
          const b = unionBounds(paths);
          annotateGroup(pip, 'dot-pip', {
            structure: 'three-concentric-forms',
            color_key: colorKey(paths[0] && paths[0].fill),
            diameter: b ? b.width : null,
            editable_unit: 'one-complete-dot-pip'
          });
          pip.bounds = b;
          pip.component_type = 'dot-pip-instance';
          stats.dot_pips++;
        }
        if (arrangement) annotateGroup(arrangement, 'dot-arrangement', { pip_count: arrangement.children.length });
      }
    } else if (tile.category === 'bams') {
      if (tile.number === 1) {
        const old = content.children.find(g => g.id === 'one-bam-bird');
        if (old) {
          const flat = flattenGroup(old, 'one-bam-bird-artwork', 'bird-artwork', 'bam-one-bird', { editable_unit: 'whole-bird-artwork' });
          content.children = content.children.map(g => g === old ? flat : g);
        }
      } else {
        const arrangement = findGroup(tile.root, 'bamboo-arrangement');
        const n = assignBambooFamilies(tile, arrangement);
        stats.upright_bamboo += n.upright;
        stats.bamboo_chevrons += n.chevrons;
        if (arrangement) annotateGroup(arrangement, 'bamboo-arrangement', { upright_count: n.upright, chevron_count: n.chevrons });
      }
    } else if (tile.category === 'craks') {
      const rank = findGroup(tile.root, 'rank-glyph');
      const wan = findGroup(tile.root, 'wan-symbol');
      if (rank) { annotateGroup(rank, 'crak-rank-glyph', { editable_unit: 'whole-rank-glyph' }); stats.rank_glyphs++; }
      if (wan) { annotateGroup(wan, 'wan-symbol', { color_key: 'red', editable_unit: 'whole-wan-glyph' }); stats.wan_symbols++; }
    }

    if (tile.category === 'dots' && tile.number === 1) {
      const g = findGroup(tile.root, 'dot-one-artwork');
      if (g) annotateGroup(g, 'dot-one-medallion', { editable_unit: 'whole-medallion' });
    }
    if (tile.category === 'bams' && tile.number === 1) {
      const g = findGroup(tile.root, 'one-bam-bird-artwork');
      if (g) annotateGroup(g, 'bam-one-bird', { editable_unit: 'whole-bird-artwork' });
    }

    if (mark) {
      const current = content.children.find(g => g.id === 'tile-index-mark');
      if (current) content.children = content.children.map(g => g === current ? mark : g);
      else content.children.push(mark);
      tile.design.corner_mark = { value: String(mark.semantic_value), position: mark.placement };
    } else if (tile.category !== 'dragons') {
      tile.design.corner_mark = null;
    }
    if (tile.category === 'flowers') {
      const meta = FLOWER_META[tile.tile_id];
      const labelGroup = makeFlowerNameGroup(tile, meta, settings);
      if (labelGroup) content.children.push(labelGroup);
    }

    tile.design = {
      ...tile.design,
      source_asset_status: tile.design.asset_status || 'usable-current-artwork',
      visual_review_status: 'pending-aesthetic-review'
    };
  }

  library.schema_version = VERSION;
  library.design_model_version = VERSION;
  library.design_rules = {
    ...(library.design_rules || {}),
    tile_aspect_ratio: '3:4',
    tile_outline_is_required: true,
    corner_mark_policy: 'single-corner: digits 1-9 for number suits; E/S/W/N for winds; flowers use one digit; dragons and Soap have no corner mark',
    dragon_policy: 'White Dragon/Soap keeps the open rectangular mark; Red and Green Dragon source artwork are placeholders pending American-style SVG replacements',
    flower_policy: 'each complete botanical artwork is one visual component; legacy source index is retained hidden; four seasons and four gentlemen flower series have numeric identifiers',
    bamboo_policy: 'all 40 upright bamboo instances reuse one canonical path geometry with per-instance transforms; the 8 Bam upper/lower chevrons are grouped as two complete motifs',
    dot_policy: 'all 44 regular Dot pips reuse three canonical ring geometries as one complete three-concentric-form visual unit; size and color remain instance parameters',
    wan_policy: 'all nine Wan glyphs share one visual component family for color, scale and placement controls; original letterform outlines are retained per tile',
    runtime_source_dependency: false
  };
  library.component_families = [
    { family_id: 'dot-pip', display_name: '筒点', instance_count: stats.dot_pips, geometry_prototypes: geometryReuse.prototype_ids.dot_pip, editable_unit: 'one complete pip', controls: ['shape', 'color', 'scale', 'position'], variants: ['concentric-3-ring'], note: 'All 44 pips reuse the same three canonical ring geometries; placement, color and scale are per-instance.' },
    { family_id: 'bamboo-upright', display_name: '直立竹子', instance_count: stats.upright_bamboo, geometry_prototype: geometryReuse.prototype_ids.bamboo_upright, editable_unit: 'one complete upright bamboo', controls: ['shape', 'color', 'scale', 'position'], variants: ['standard', 'compact'], note: 'All 40 upright sticks reuse one canonical bamboo geometry; instance transforms preserve placement and size.' },
    { family_id: 'bamboo-chevron', display_name: '8索V形竹组', instance_count: stats.bamboo_chevrons, editable_unit: 'one complete two-arm motif', controls: ['color', 'scale', 'position', 'orientation'], variants: ['upper', 'lower'], note: 'The upper and lower V motifs each contain their two original arms.' },
    { family_id: 'wan-symbol', display_name: '萬字', instance_count: stats.wan_symbols, geometry_prototype: geometryReuse.prototype_ids.wan_symbol, editable_unit: 'whole glyph', controls: ['shape', 'color', 'scale', 'position'], variants: ['original outlined glyph'], note: 'All nine tiles reuse one canonical Wan glyph geometry with per-tile transform and shared color controls.' },
    { family_id: 'crak-rank-glyph', display_name: '万牌数字', instance_count: stats.rank_glyphs, editable_unit: 'whole glyph', controls: ['color', 'scale', 'position'], variants: ['1-9'], note: 'Original number outlines are kept; no font substitution.' },
    { family_id: 'wind-glyph', display_name: '风牌字形', instance_count: 4, editable_unit: 'whole glyph', controls: ['color', 'scale', 'position'], variants: ['E', 'S', 'W', 'N'] },
    { family_id: 'flower-artwork', display_name: '完整花牌图案', instance_count: stats.flower_artwork_groups, editable_unit: 'whole artwork', controls: ['move', 'scale', 'rotate', 'recolor individual paths'], variants: ['Spring', 'Summer', 'Autumn', 'Winter', 'Plum', 'Orchid', 'Bamboo', 'Chrysanthemum'], note: 'No petal, leaf or stem subgroups are exposed for routine editing; small series label and one-digit index are separate text groups.' },
    { family_id: 'dot-one-medallion', display_name: '一筒徽章', instance_count: 1, editable_unit: 'whole artwork', controls: ['move', 'scale', 'recolor individual paths'] },
    { family_id: 'bam-one-bird', display_name: '一索鸟形', instance_count: 1, editable_unit: 'whole artwork', controls: ['move', 'scale', 'recolor individual paths'] },
    { family_id: 'dragon-white-soap', display_name: '白龙 / Soap', instance_count: 1, editable_unit: 'whole artwork', controls: ['move', 'scale'] },
    { family_id: 'dragon-red-placeholder', display_name: '红龙待替换素材', instance_count: 1, editable_unit: 'whole artwork', controls: ['replace artwork'], note: 'Current Chinese 中 glyph is a temporary placeholder.' },
    { family_id: 'dragon-green-placeholder', display_name: '绿龙待替换素材', instance_count: 1, editable_unit: 'whole artwork', controls: ['replace artwork'], note: 'Current Chinese 發 glyph is a temporary placeholder.' }
  ];
  library.asset_completeness = {
    present_visual_masters: 42,
    present_number_tiles: 27,
    present_winds: 4,
    present_dragon_slots: 3,
    accepted_dragon_artwork: ['White Dragon / Soap'],
    dragon_artwork_replacements_needed: ['Red Dragon', 'Green Dragon'],
    present_flower_artwork: 8,
    extra_flower_artwork_needed: ['Fu', 'Lu', 'Shou', 'Gui'],
    joker_artwork_present: false,
    corner_marked_number_tiles: 27,
    corner_marked_flowers: 8,
    corner_marked_winds: 4,
    dragons_with_corner_marks: 0,
    status: 'base_structure_present_but_not_all_american_mahjong_artwork_is_final'
  };
  library.semantic_statistics = { ...(library.semantic_statistics || {}), design_model: stats, shared_visual_geometry_reuse: geometryReuse };
  return library;
}

module.exports = { VERSION, WIND_OFFSETS, FLOWER_META, applyDesignModel };
