@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
set "LOG=%~dp0logs\first_absorb.log"
set "RC=0"
(
  echo American Mahjong Asset Studio v0.4.0
  echo Started: %DATE% %TIME%
  echo Project folder: %~dp0
  echo.
  echo Checking Node.js...
  where.exe node
  node --version
) >"%LOG%" 2>&1
where.exe node >nul 2>&1
if errorlevel 1 (
  set "RC=9009"
  >>"%LOG%" echo ERROR: Node.js was not found in PATH.
  goto :finish
)
>>"%LOG%" echo.
>>"%LOG%" echo Checking source SVG and absorbing it...
node "%~dp0src\absorb_source.js" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto :finish
>>"%LOG%" echo.
>>"%LOG%" echo Verifying asset library...
node "%~dp0src\verify_library.js" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto :finish
>>"%LOG%" echo.
>>"%LOG%" echo Rendering previews...
node "%~dp0src\render_library.js" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto :finish
>>"%LOG%" echo.
>>"%LOG%" echo SUCCESS: First absorption, verification and render completed.
:finish
echo.
echo ================================================
echo American Mahjong Asset Studio - run result
echo ================================================
echo Exit code: %RC%
echo Log file: %LOG%
echo.
if exist "%LOG%" type "%LOG%"
echo.
if "%RC%"=="0" (
  echo Completed. Press any key to open the preview.
  pause >nul
  if exist "%~dp0output\preview.html" start "" "%~dp0output\preview.html"
) else (
  echo FAILED. The window will stay open until you press a key.
  echo Please send logs\first_absorb.log for diagnosis.
  pause >nul
)
exit /b %RC%
