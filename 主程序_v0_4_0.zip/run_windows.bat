@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0\library\asset_library.json" (
  call "%~dp0\02_RENDER_FROM_LIBRARY.bat"
) else (
  call "%~dp0\01_FIRST_ABSORB.bat"
)
exit /b %ERRORLEVEL%
