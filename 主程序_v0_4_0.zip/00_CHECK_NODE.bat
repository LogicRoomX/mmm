@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo Project folder: %~dp0
echo.
where.exe node
if errorlevel 1 (
  echo Node.js was not found. Install the Windows LTS version, then reopen this window.
) else (
  node --version
  echo Node.js is available.
)
echo.
echo This check does not modify project files.
pause
