# American Mahjong Asset Studio v0.4.0

本项目以 `library/asset_library.json` 为唯一运行时美术资产来源。它不会在日常渲染时读取原始 `无底.svg`。

## 本版纳入的设计规则

- 牌面比例3:4；外框仍然是每张牌的必要组成部分，默认线宽10。
- 数字牌（Bams/Craks/Dots）左上角只显示一个数字1–9，不添加B/C/D字母。
- 风牌左上角显示E/S/W/N。
- 花牌显示单个数字1–4：春夏秋冬分别1/2/3/4；梅兰竹菊分别1/2/3/4。四季系列数字在左上角、右上角写英文缩写SPR/SUM/AUT/WIN；梅兰竹菊系列英文名称PLUM/ORCHID/BAMBOO/CHRYSANTHEMUM在左上角，数字在右上角。
- 龙牌不加角标。White Dragon/Soap 保留现有空心矩形；不加0。Red/Green Dragon的现有中/发图案只是等待替换的占位，不作为最终美式龙牌设计。
- 花牌每张植物图案作为一个整体 `flower-artwork` 组件，不把花瓣、叶片、枝干拆成日常编辑组件。
- 2–9筒的44颗普通筒点作为一个整体视觉家族 `dot-pip`；全部复用3条规范圆环几何，单颗的颜色、尺寸和位置独立控制。
- 2–9索的40根直立竹子作为 `bamboo-upright` 家族并共用一条规范几何；8索中上V和下V分别作为完整的两臂图案组。
- 1筒徽章、1索鸟形也作为完整视觉单元。
- 1–9万共用同一条 `wan-symbol` 矢量几何，按牌面实例调整位置和大小；颜色由组件家族统一管理。

> 筒点、直立竹子和萬字已提炼为可复用的规范几何；迁移前的原始路径几何和原矩阵另存于组件定义与 `original_component_id` / `original_matrix` 记录中，便于追溯。

## 第一次运行/从旧版升级

1. 解压本项目完整 ZIP。
2. 保留 `library/asset_library.json`。本包已经包含用户当前的资产库。
3. 双击 `02_RENDER_FROM_LIBRARY.bat`。
4. 脚本会先把旧版0.3资产库自动升级为0.4，并保留 `asset_library.json.pre-v0.4.0.bak` 备份，然后验证和渲染。
5. 打开 `output/preview.html` 查看42张牌。

如果重新吸收原始SVG，先把它放入 `input/无底.svg`，再运行 `01_FIRST_ABSORB.bat`。新版吸收程序会直接生成0.4设计模型，不必再次迁移。

## 输出

- `library/asset_library.json`：独立资产库。升级前会创建备份。
- `output/preview.html`：42张牌的总览。花牌预览顺序为春夏秋冬、梅兰竹菊。
- `output/tiles/`：每张牌的独立SVG。
- `output/render_manifest.json`：分组与视觉组件清单。
- `output/RENDER_REPORT.md`：资产完整性及仍待补充素材清单。
- `logs/render_from_library.log`：运行日志。

## 当前素材完整性

现有42张视觉母版包括27张数字牌、4张风牌、3张龙牌和8张花牌。当前能作为基础保留的龙牌是White Dragon/Soap；Red Dragon和Green Dragon需要替换。还缺4张福禄寿贵扩展花牌和1张Joker母版。它们不会用虚构图案填充，会等用户提供SVG后接入。

## 环境

- Windows 10/11
- Node.js 18或更高版本
- 无第三方npm依赖

检查Node：`00_CHECK_NODE.bat`
运行验证与渲染：`02_RENDER_FROM_LIBRARY.bat`
