export type Suit = 'man' | 'pin' | 'sou' | 'wind' | 'dragon' | 'back';
export type Wind = 'east' | 'south' | 'west' | 'north';
export type Dragon = 'white' | 'green' | 'red';

export interface Tile {
  /** Tile category. */
  suit: Suit;
  /** 1-9 for suited tiles, a wind/dragon name for honors, or "back". */
  value: number | Wind | Dragon | 'back';
  /** True for red fives (aka dora). */
  red: boolean;
  /** Canonical notation code, e.g. "5m", "0p", "1z", "back". */
  code: string;
}

export interface RenderOptions {
  /** Face width in px (default 60). */
  width?: number;
  /** Face height in px (default 80). */
  height?: number;
  /** Corner radius in px (default 8). */
  radius?: number;
  /** Faux-3D thickness on the bottom/right edge (default 4). */
  depth?: number;
  /** Spacing between tiles in a hand, in px (default 6). */
  gap?: number;
  /** Draw vertical ribbing on face-down (back) tiles (default true). */
  backRibs?: boolean;
  /** Face-down back base color (bottom of gradient). */
  backColor?: string;
  /** Face-down back highlight color (top of gradient). */
  backColorTop?: string;
  /** Color of the back's vertical ribbing. */
  backRibColor?: string;
  /**
   * When true, the root <svg> uses width/height="100%" instead of fixed px, so
   * the viewBox scales the tile to fill its container (no CSS override needed).
   * Default false (fixed px size from width/height/depth).
   */
  fit?: boolean;
  /** Background fill for the SVG; null/omitted = transparent. */
  background?: string | null;
  /** Tile face base color. */
  faceColor?: string;
  /** Tile face highlight color (top of gradient). */
  faceColorTop?: string;
  /** Border color. */
  edgeColor?: string;
  /**
   * Back color shown along the faux-3D edge of a face-up tile. Defaults to
   * `backColor` (so the edge matches the back) unless set explicitly.
   */
  sideColor?: string;
  /** Darker green for a face-down (back) tile's own faux-3D edge. */
  sideShadow?: string;
}

/** Parse notation (string or token array) into tile objects. */
export function parseHand(input: string | string[]): Tile[];

/** Parse a single tile from notation, or pass through a tile object. */
export function parseTile(tile: string | Tile): Tile;

/** Render a single tile to a standalone SVG string. */
export function tileToSvg(tile: string | Tile, options?: RenderOptions): string;

/** Render a row of tiles (a hand) to a single SVG string. */
export function handToSvg(
  hand: string | string[] | Tile[],
  options?: RenderOptions
): string;

/**
 * Human-readable label for a tile, e.g. "5 circles", "white dragon", "east wind"
 * (also used for the SVG aria-label). Accepts notation ("5z") or a tile object.
 */
export function tileLabel(tile: string | Tile): string;

export const DEFAULTS: Required<Omit<RenderOptions, 'background'>> & {
  background: string | null;
};
export const WINDS: Wind[];
export const DRAGONS: Dragon[];
