# tilekit

Render mahjong tiles to SVG. Works in Node and the browser. Single runtime
dependency (`hanzi-writer-data`); no `<text>` elements, so output is
font-independent.

## Layout

- `src/index.js` — public entry point; re-exports the API.
- `src/notation.js` — parse compact notation (`123m`, `5z`, `E`, `back`) into tile objects.
- `src/render.js` — SVG rendering (`tileToSvg`, `handToSvg`, layouts, palette wiring).
- `src/glyphs.js` — CJK character glyphs sourced from `hanzi-writer-data` at runtime.
- `src/palette.js` — shared colors.
- `bin/tilekit.js` — CLI.
- `index.d.ts` — TypeScript types for the public API.
- `test/` — `node --test` suites.

## Rules

- **Always update `index.d.ts` when the public API changes.** Any new or
  changed export, function signature, option, or tile field in `src/` must be
  reflected in the type definitions in the same change. The types are shipped
  and must stay in sync with the runtime — treat a mismatch as a bug.
- Keep `README.md`'s options table and notation table in sync with `DEFAULTS`
  in `src/render.js` and the parser in `src/notation.js`.

## Commands

- `npm test` — run the test suite (`node --test`).
- `npm run example` — write sample SVGs to `examples/`.
