// Parse mahjong tile notation into structured tile objects.
//
// Supported notation
//   Suited (riichi/tenhou compact form):
//     "123m"  -> 1,2,3 of characters (man / 萬)
//     "456p"  -> 4,5,6 of circles    (pin / 筒)
//     "789s"  -> 7,8,9 of bamboo     (sou / 索)
//     "0m"/"0p"/"0s" -> red five of that suit
//   Honors:
//     "1z".."4z" -> winds East, South, West, North
//     "5z".."7z" -> dragons White, Green, Red
//     aliases: E S W N  (winds), wd gd rd (dragons)
//   Other:
//     "back" / "0z" -> face-down tile
//
// Tokens may be separated by spaces or written contiguously
// ("123m456p77z" is the same as "123m 456p 77z").

const WINDS = ['east', 'south', 'west', 'north'];
const DRAGONS = ['white', 'green', 'red'];

const WIND_ALIAS = { e: 'east', s: 'south', w: 'west', n: 'north' };
const DRAGON_ALIAS = { wd: 'white', gd: 'green', rd: 'red' };

const SUIT_OF_LETTER = { m: 'man', p: 'pin', s: 'sou' };

function suitedTile(value, suit) {
  const red = value === 0;
  const num = red ? 5 : value;
  if (num < 1 || num > 9) {
    throw new Error(`Invalid ${suit} value: ${value}`);
  }
  return {
    suit,
    value: num,
    red,
    code: `${red ? 0 : num}${suit === 'man' ? 'm' : suit === 'pin' ? 'p' : 's'}`,
  };
}

function honorTile(value) {
  // value 1..7 in z-notation, 0 = back
  if (value === 0) return { suit: 'back', value: 'back', red: false, code: 'back' };
  if (value >= 1 && value <= 4) {
    const name = WINDS[value - 1];
    return { suit: 'wind', value: name, red: false, code: `${value}z` };
  }
  if (value >= 5 && value <= 7) {
    const name = DRAGONS[value - 5];
    return { suit: 'dragon', value: name, red: false, code: `${value}z` };
  }
  throw new Error(`Invalid honor value: ${value}`);
}

function windTile(name) {
  return { suit: 'wind', value: name, red: false, code: `${WINDS.indexOf(name) + 1}z` };
}

function dragonTile(name) {
  return { suit: 'dragon', value: name, red: false, code: `${DRAGONS.indexOf(name) + 5}z` };
}

// Expand a contiguous run like "123m" or "0p" into tile objects.
function expandRun(digits, letter) {
  const suit = SUIT_OF_LETTER[letter];
  const tiles = [];
  for (const ch of digits) {
    const value = Number(ch);
    if (letter === 'z') tiles.push(honorTile(value));
    else tiles.push(suitedTile(value, suit));
  }
  return tiles;
}

/**
 * Parse a notation string (or array of tokens) into an array of tile objects.
 * @param {string|string[]} input
 * @returns {Array<object>}
 */
export function parseHand(input) {
  if (Array.isArray(input)) return input.flatMap(parseHand);
  const text = String(input).trim();
  if (text === '') return [];

  const tiles = [];
  // Match either a compact run (digits + suit letter) or a standalone alias word.
  const tokenRe = /([0-9]+)([mpsz])|([a-zA-Z]+)/g;
  let match;
  let consumed = 0;
  while ((match = tokenRe.exec(text)) !== null) {
    consumed = tokenRe.lastIndex;
    if (match[1] !== undefined) {
      tiles.push(...expandRun(match[1], match[2]));
      continue;
    }
    const word = match[3].toLowerCase();
    if (word === 'back') {
      tiles.push(honorTile(0));
    } else if (WIND_ALIAS[word]) {
      tiles.push(windTile(WIND_ALIAS[word]));
    } else if (DRAGON_ALIAS[word]) {
      tiles.push(dragonTile(DRAGON_ALIAS[word]));
    } else {
      throw new Error(`Unrecognized tile token: "${match[3]}"`);
    }
  }
  // Reject leftover garbage (e.g. a digit run with no suit letter).
  const leftover = text.slice(consumed).replace(/[\s]/g, '');
  if (leftover !== '' || (tiles.length === 0 && text !== '')) {
    if (!tokenRe.test(text)) throw new Error(`Could not parse notation: "${text}"`);
  }
  return tiles;
}

/**
 * Parse a single tile from a string or pass through a tile object.
 * @param {string|object} tile
 * @returns {object}
 */
export function parseTile(tile) {
  if (tile && typeof tile === 'object') return tile;
  const parsed = parseHand(tile);
  if (parsed.length !== 1) {
    throw new Error(`Expected a single tile, got ${parsed.length} from "${tile}"`);
  }
  return parsed[0];
}

export { WINDS, DRAGONS };
