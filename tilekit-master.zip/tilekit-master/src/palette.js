// Color palette for tilekit tiles. Centralizing these keeps the suit colors and
// the face tone consistent across the tile body, the pips, and the glyph art.

// The tile face cream. Reused by pips and bamboo cores that sit on the face and
// need to "cut out" to the same tone as the face behind them, so it must stay in
// sync with the face color in DEFAULTS.
export const FACE_CREAM = '#fbf7ec';

export const COLORS = {
  manNum: '#21349e', // royal blue, matching traditional tile sets
  manKanji: '#a01f28',
  pin: ['#21349e', '#1f8a3b', '#a01f28'],
  sou: '#1f7a34',
  souAccent: '#a01f28',
  wind: '#21349e',
  dragonGreen: '#1f8a3b',
  dragonRed: '#a01f28',
  back: '#6f9b3e', // green face-down back (classic two-tone tile)
  backTop: '#7faa49', // top of the back gradient
  backRib: '#587d2e', // darker green for the back's vertical ribbing
};
