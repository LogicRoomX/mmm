// SVG rendering for mahjong tiles. No runtime dependencies.
import { parseTile, parseHand } from './notation.js';
import { glyphSvg } from './glyphs.js';
import { COLORS, FACE_CREAM } from './palette.js';

const DEFAULTS = {
  width: 60, // face width
  height: 80, // face height
  radius: 8, // corner radius
  depth: 4, // fake 3D thickness on bottom/right
  gap: 6, // spacing between tiles in a hand
  backRibs: true, // draw vertical ribbing on face-down (back) tiles
  backColor: COLORS.back, // face-down back base color (bottom of gradient)
  backColorTop: COLORS.backTop, // face-down back highlight (top of gradient)
  backRibColor: COLORS.backRib, // color of the back's vertical ribbing
  fit: false, // root <svg> uses width/height="100%" (scales via viewBox) instead of fixed px
  background: null, // svg background (null = transparent)
  faceColor: FACE_CREAM,
  faceColorTop: '#fffefa',
  edgeColor: '#cdbf9f',
  sideColor: '#6f9b3e', // green back color shown along the faux-3D edge
  sideShadow: '#587d2e', // darker green for the back tile's own edge
};

function esc(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function round(num) {
  return Math.round(num * 1000) / 1000;
}

// Dot positions for circles (pin), as fractions of the inner face box.
// Mirrors the traditional 1-9 circle arrangements.
function pinLayout(n) {
  const L = {
    1: [[0.5, 0.5]],
    2: [[0.5, 0.28], [0.5, 0.72]],
    3: [[0.21, 0.19], [0.5, 0.5], [0.79, 0.81]],
    4: [[0.25, 0.27], [0.75, 0.27], [0.25, 0.73], [0.75, 0.73]],
    5: [[0.24, 0.25], [0.76, 0.25], [0.5, 0.5], [0.24, 0.75], [0.76, 0.75]],
    // 2 on top, separated from a 2x2 block of 4 below.
    6: [[0.3, 0.15], [0.7, 0.15], [0.3, 0.53], [0.7, 0.53], [0.3, 0.83], [0.7, 0.83]],
    // Classic 7: a diagonal row of three over a 2x2 of four.
    7: [[0.27, 0.16], [0.5, 0.25], [0.73, 0.34], [0.32, 0.63], [0.68, 0.63], [0.32, 0.85], [0.68, 0.85]],
    8: [[0.31, 0.18], [0.69, 0.18], [0.31, 0.39], [0.69, 0.39], [0.31, 0.61], [0.69, 0.61], [0.31, 0.82], [0.69, 0.82]],
    9: [[0.25, 0.22], [0.5, 0.22], [0.75, 0.22], [0.25, 0.5], [0.5, 0.5], [0.75, 0.5], [0.25, 0.78], [0.5, 0.78], [0.75, 0.78]],
  };
  return L[n] || [];
}

// Stick positions for bamboo (sou). These follow the traditional bamboo
// groupings, which differ from circles: 3 is a triangle, 6 is 3x2, and
// 7/8/9 stack rows of 1/2/3 over 3 over 3. (1 is drawn as a bird elsewhere.)
function souLayout(n) {
  const L = {
    2: [[0.5, 0.22], [0.5, 0.78]],
    3: [[0.5, 0.18], [0.27, 0.8], [0.73, 0.8]],
    4: [[0.29, 0.23], [0.71, 0.23], [0.29, 0.77], [0.71, 0.77]],
    5: [[0.26, 0.22], [0.74, 0.22], [0.5, 0.5], [0.26, 0.78], [0.74, 0.78]],
    6: [[0.22, 0.23], [0.5, 0.23], [0.78, 0.23], [0.22, 0.77], [0.5, 0.77], [0.78, 0.77]],
    7: [[0.5, 0.12], [0.24, 0.5], [0.5, 0.5], [0.76, 0.5], [0.24, 0.88], [0.5, 0.88], [0.76, 0.88]],
    8: [[0.36, 0.16], [0.64, 0.16], [0.28, 0.5], [0.5, 0.5], [0.72, 0.5], [0.28, 0.83], [0.5, 0.83], [0.72, 0.83]],
    9: [[0.22, 0.15], [0.5, 0.15], [0.78, 0.15], [0.22, 0.5], [0.5, 0.5], [0.78, 0.5], [0.22, 0.85], [0.5, 0.85], [0.78, 0.85]],
  };
  return L[n] || [];
}

function circlePip(cx, cy, r, color) {
  // Concentric "target": a center dot with two rings around it, alternating
  // the dot color with the face color (as on real circles/pin tiles).
  const disc = (radius, fill) =>
    `<circle cx="${round(cx)}" cy="${round(cy)}" r="${round(radius)}" fill="${fill}"/>`;
  const white = FACE_CREAM;
  return (
    disc(r, color) + // outer ring
    disc(r * 0.72, white) +
    disc(r * 0.56, color) + // inner ring
    disc(r * 0.34, white) +
    disc(r * 0.2, color) // center dot
  );
}

// Per-position colors for each circles (pin) tile, in pinLayout order.
// Traditional sets color these by tile, not by a repeating cycle.
function pinColors(value) {
  const [blue, green, red] = COLORS.pin;
  switch (value) {
    case 2: return [green, blue];
    case 3: return [green, red, blue];
    case 4: return [blue, green, green, blue];
    case 5: return [blue, green, red, green, blue];
    case 6: return [green, green, red, red, red, red];
    case 7: return [green, green, green, red, red, red, red];
    case 8: return [blue, blue, blue, blue, blue, blue, blue, blue];
    case 9: return [green, green, green, red, red, red, blue, blue, blue];
    default: return [];
  }
}

// The 1 of circles is a single ornate flower: a ring of green petals around a
// blue / red / blue concentric center.
function flowerPip(cx, cy, radius) {
  const [blue, green, red] = COLORS.pin;
  const petalDist = radius * 0.66;
  let out = '';
  for (let idx = 0; idx < 12; idx++) {
    const deg = (idx * 360) / 12;
    const rad = (deg * Math.PI) / 180;
    const ex = cx + petalDist * Math.cos(rad);
    const ey = cy + petalDist * Math.sin(rad);
    out +=
      `<ellipse cx="${round(ex)}" cy="${round(ey)}" rx="${round(radius * 0.12)}" ry="${round(radius * 0.24)}" ` +
      `fill="${FACE_CREAM}" stroke="${green}" stroke-width="${round(radius * 0.05)}" ` +
      `transform="rotate(${round(deg - 90)} ${round(ex)} ${round(ey)})"/>`;
  }
  const rings = [[0.34, blue], [0.26, FACE_CREAM], [0.2, red], [0.12, FACE_CREAM], [0.07, blue]];
  for (const [frac, col] of rings) {
    out += `<circle cx="${round(cx)}" cy="${round(cy)}" r="${round(radius * frac)}" fill="${col}"/>`;
  }
  return out;
}

// Darken a #rrggbb color by a factor (0..1) — used for bamboo outlines/nodes.
function darken(hex, factor) {
  const num = parseInt(hex.slice(1), 16);
  const channel = (shift) => Math.round(((num >> shift) & 255) * factor);
  return (
    '#' +
    [channel(16), channel(8), channel(0)]
      .map((value) => value.toString(16).padStart(2, '0'))
      .join('')
  );
}

// A barrel-shaped bamboo segment: narrow (ew) at the rounded ends, bulging to
// hw at the sides — stacked two-per-stalk to read as jointed bamboo.
function barrelPath(cx, top, bot, ew, hw) {
  const span = bot - top;
  const capT = top - span * 0.05;
  const capB = bot + span * 0.05;
  return (
    `M ${round(cx - ew)},${round(top)} ` +
    `C ${round(cx - hw)},${round(top + span * 0.3)} ${round(cx - hw)},${round(bot - span * 0.3)} ${round(cx - ew)},${round(bot)} ` +
    `Q ${round(cx)},${round(capB)} ${round(cx + ew)},${round(bot)} ` +
    `C ${round(cx + hw)},${round(bot - span * 0.3)} ${round(cx + hw)},${round(top + span * 0.3)} ${round(cx + ew)},${round(top)} ` +
    `Q ${round(cx)},${round(capT)} ${round(cx - ew)},${round(top)} Z`
  );
}

// One bamboo stalk: three barrel segments stacked at pinched nodes, each with a
// darker outline and a light core line down the middle (split-bamboo look).
const BAMBOO_SEGMENTS = 3;
function bambooStick(cx, cy, w, h, color) {
  const dark = darken(color, 0.6);
  const ew = w * 0.32;
  const hw = w * 0.5;
  const gap = h * 0.03;
  const segH = (h - gap * (BAMBOO_SEGMENTS - 1)) / BAMBOO_SEGMENTS;
  const top = cy - h / 2;
  const sw = round(w * 0.16);
  const coreW = round(w * 0.22);
  let out = '';
  for (let idx = 0; idx < BAMBOO_SEGMENTS; idx++) {
    const a = top + idx * (segH + gap);
    const b = a + segH;
    const inset = segH * 0.16;
    out +=
      `<path d="${barrelPath(cx, a, b, ew, hw)}" fill="${color}" stroke="${dark}" ` +
      `stroke-width="${sw}" stroke-linejoin="round"/>` +
      `<line x1="${round(cx)}" y1="${round(a + inset)}" x2="${round(cx)}" y2="${round(b - inset)}" ` +
      `stroke="${FACE_CREAM}" stroke-width="${coreW}" stroke-linecap="round"/>`;
  }
  return out;
}

// A bamboo stalk drawn along an arbitrary line segment (used for the angled 8).
function bambooAlong(x1, y1, x2, y2, w, color) {
  const cx = (x1 + x2) / 2;
  const cy = (y1 + y2) / 2;
  const len = Math.hypot(x2 - x1, y2 - y1);
  const deg = (Math.atan2(y2 - y1, x2 - x1) * 180) / Math.PI - 90;
  return `<g transform="rotate(${round(deg)} ${round(cx)} ${round(cy)})">${bambooStick(cx, cy, w, len, color)}</g>`;
}

// The 8 of bamboo: two stacked "M" motifs, each a pair of vertical outer stalks
// with two inner diagonals meeting at a centre notch.
function souEight(padX, padY, innerW, innerH, color) {
  const xAt = (frac) => padX + frac * innerW;
  const w = innerW / 7.6;
  const xL = xAt(0.2);
  const xC = xAt(0.5);
  const xR = xAt(0.8);
  const yA = padY + innerH * 0.06; // top of upper M
  const yB = padY + innerH * 0.47; // bottom of upper M
  const yC = padY + innerH * 0.53; // top of lower M
  const yD = padY + innerH * 0.94; // bottom of lower M
  // One M motif: two full-height verticals plus inner diagonals that meet at a
  // centre point. `flipped` puts that point at the top (peak) instead of the
  // bottom (notch), so the two rows mirror each other.
  const mRow = (vTop, vBot, flipped) => {
    // The inner apex is inset from the vertical ends, so the outer stalks reach
    // further than the centre point (peak sits below the tops, notch above the
    // bottoms).
    const inset = (vBot - vTop) * 0.22;
    const outerY = flipped ? vBot : vTop;
    const centreY = flipped ? vTop + inset : vBot - inset;
    return (
      bambooAlong(xL, vTop, xL, vBot, w, color) + // left vertical
      bambooAlong(xL, outerY, xC, centreY, w, color) +
      bambooAlong(xC, centreY, xR, outerY, w, color) +
      bambooAlong(xR, vTop, xR, vBot, w, color) // right vertical
    );
  };
  return mRow(yA, yB, true) + mRow(yC, yD, false);
}

// The 1 of bamboo: a stylized crested bird in the folk two-tone manner — a red
// crested head and a sword-like red tail over a green woven body. The two colour
// paths live in a natural 292x412 art box whose top-left sits at (82,80); the
// wrapping group normalizes that to the origin and scales the whole thing to fill
// the face. `fill-rule="evenodd"` carves the eye and the white gaps out of each
// colour.
const BIRD_ART_W = 292;
const BIRD_ART_H = 412;
const BIRD_ART_OFFX = 82;
const BIRD_ART_OFFY = 80;
const BIRD_GREEN_PATH =
  'M 227.2 148.7 C 215.7 154.3, 216.6 173.7, 228.7 179.5 C 245.1 187.4, 260.6 173.3, 253.6 156.7 C 250 147.9, 236.9 143.9, 227.2 148.7 M 297.2 150.5 C 294.4 152.5, 292 154.5, 292 155 C 292 156.6, 284.9 164, 281.9 165.5 C 280.3 166.4, 277.1 170.3, 274.4 174.7 C 268.9 183.8, 261 192.4, 255.8 195.1 C 251.5 197.3, 216.7 198, 212.8 195.9 C 207.9 193.3, 205.4 178.7, 207.9 167.8 C 209.2 162.3, 208.5 162.1, 187.3 161.9 L 168.2 161.7 161.2 166.4 C 137.3 182.3, 133.1 208.6, 147.6 251.8 C 150.8 261.1, 150.5 263.8, 146.1 266.7 C 139.6 271.1, 133.3 268.5, 131.1 260.6 C 126.2 242.6, 99.8 236.3, 92.2 251.2 C 77.7 279.9, 96.9 301.3, 127.1 290 C 136 286.6, 135.2 291.1, 125.5 298.3 C 123.1 300.1, 118.8 303.6, 115.8 306.2 C 112.9 308.7, 109.3 311.1, 108 311.5 C 103.4 312.7, 87.5 324.3, 87.2 326.8 C 86.8 329.8, 89.7 329.7, 97.5 326.5 C 100.8 325.1, 104.2 324, 105 324 C 107.2 324, 133.9 310.5, 136.4 308.1 C 137.6 307, 140.2 305.4, 142.2 304.6 C 150.6 301, 157.4 296.1, 160.4 291.2 C 164.5 284.6, 177 271, 179 271 C 181.2 271.1, 191.5 275.9, 198.5 280.1 C 209.8 286.9, 223.8 287.9, 235.7 282.6 C 243.6 279, 244.5 279.4, 254.5 289.1 C 273 307.1, 304.7 306.4, 308.4 287.9 C 310.4 277.7, 315.9 274.8, 328.2 277.1 C 334.2 278.2, 335.7 278.1, 340.9 276.5 C 345.8 275, 347.3 275, 350.5 276 C 365.2 280.8, 375.4 273.2, 372.5 259.4 C 365.9 227.4, 328.7 221.7, 325.3 252.1 C 324 263.7, 313.5 264.7, 307.9 253.8 C 300.8 239.8, 301.5 234.5, 312.1 222 C 327.5 204, 332.2 188.3, 328.1 169.4 C 323.7 148.9, 311.1 141.2, 297.2 150.5 M 233.3 156.3 C 230.3 159.6, 229.7 162.5, 231.4 165.8 C 234.3 171.5, 242.4 172.4, 245.6 167.5 C 250.2 160.4, 238.9 150.1, 233.3 156.3 M 292 171.6 C 286.3 176.4, 286 178, 286 199.8 C 286 220, 286.6 223.6, 290 221.5 C 291.6 220.5, 303 196.3, 303 193.8 C 303 192.5, 303.4 190, 303.9 188.2 C 305 184.6, 303 173, 301 170.4 C 299.1 168.2, 295.5 168.7, 292 171.6 M 171.9 177.6 C 168.1 182.2, 188.2 199.4, 192.4 195 C 195.3 191.9, 195.4 181.3, 192.6 178.5 C 189.5 175.4, 174.3 174.7, 171.9 177.6 M 159.9 192.8 C 157.3 199.6, 160.7 208, 167.3 211 C 169.6 212.1, 173.5 214.1, 176 215.5 C 181.4 218.5, 184.3 218.7, 187 216 C 191.1 211.9, 188 204.6, 180.8 200.9 C 178.4 199.7, 174 196.8, 170.9 194.4 C 164.4 189.2, 161.4 188.8, 159.9 192.8 M 262.3 204.8 C 259.6 206.5, 257.2 214.6, 256.6 224.3 C 256 234.6, 255.3 236.8, 251.2 241.3 C 246.2 246.6, 245.4 243.9, 248.6 232 C 252.4 217.7, 251.7 209, 246.9 209 C 243.7 209, 242 213, 242 220.6 C 242 228.6, 241.2 231.3, 234.7 245 C 232.3 250.2, 230 255.5, 229.6 256.6 C 228.7 259.6, 225.4 262.4, 223.5 261.7 C 221.3 260.8, 221.6 256.4, 224.6 248.5 C 233.9 223.7, 235.7 211, 230 211 C 227 211, 226.5 212, 220.5 231.9 C 216.4 245.3, 204.6 259.4, 202.4 253.5 C 201.6 251.6, 205.3 243, 209 237.4 C 215.7 227.7, 216.5 208.1, 210.3 207.2 C 207.5 206.8, 206.7 208.4, 203.5 220.8 C 201 230.9, 199.2 234.4, 189.5 248 C 181 260.1, 196.5 273, 219.7 273 C 238.6 273, 262.4 253, 265.1 234.8 C 268.3 213.9, 267.1 201.7, 262.3 204.8 M 164.7 222.7 C 163.7 223.7, 163.9 235.6, 164.9 238.2 C 165.4 239.5, 166.1 241.7, 166.4 243.1 C 168.1 250.8, 179 239.5, 179 230 C 179 226.3, 167.1 220.2, 164.7 222.7 M 341.7 249.8 C 336.9 255, 343 261, 348 256 C 350.4 253.6, 350.5 251.7, 348.4 249.6 C 346.3 247.5, 343.7 247.6, 341.7 249.8 M 279 255.7 C 273.9 261.5, 274.1 263.5, 279.7 263.4 C 285.3 263.3, 289 260.8, 289 257.1 C 289 249.4, 285.1 248.9, 279 255.7 M 104.4 259.4 C 99.1 264.7, 100.6 270.8, 107.5 272.6 C 116.7 274.9, 121.8 262.9, 113.7 258 C 109.4 255.3, 108.3 255.5, 104.4 259.4 M 269.9 279.9 L 267.6 281.7 270.3 284.4 C 275.4 289.5, 293 287.2, 293 281.5 C 293 277.6, 274.3 276.3, 269.9 279.9';
const BIRD_RED_PATH =
  'M 189.4 83.6 C 177.8 89.7, 170.6 104.2, 174.5 113.7 C 178 121.9, 179.9 121.5, 143.5 119.7 C 133.6 119.3, 136.6 124.4, 150.5 132 C 153.8 133.8, 156.9 135.6, 157.5 136 C 167 143, 193.5 151.9, 204.7 152 C 210.6 152, 212 150.6, 212 144.7 C 212 138.7, 222.3 131, 232.5 129.3 C 243.7 127.5, 264 147.1, 264 159.8 C 264 168.3, 270.2 165.7, 275.6 155 C 279.9 146.7, 280.5 142.5, 278.5 136.9 C 274.8 127.2, 274.6 127.7, 285.7 124.1 C 307.9 116.8, 335.3 91.1, 329 83.5 C 326.5 80.5, 324.9 81.2, 312.3 91 C 309.1 93.5, 305.3 96.3, 303.9 97.2 C 290.6 105.7, 253.2 105.1, 239.9 96.3 C 238.4 95.3, 233.7 92, 229.4 89 C 216.4 80.1, 200.3 77.9, 189.4 83.6 M 197.6 101.9 C 193.9 106, 200.8 116.1, 208.3 117.5 C 214 118.6, 228 113.2, 228 110 C 228 103.7, 202.2 96.8, 197.6 101.9 M 189.6 288.5 C 187.6 290.5, 187.5 288.2, 191 306 C 199.3 348, 210.7 384.2, 222.6 406.5 C 223.5 408.1, 225.9 412.6, 228 416.5 C 239.7 438.3, 272.2 487.8, 276.5 490.3 C 285.5 495.4, 279.9 481.3, 263.1 456 C 257.5 447.7, 251.8 432.7, 247 414 C 242.6 397.1, 241.2 378.9, 240.2 329 C 239.4 289.5, 239.5 289.8, 232.4 293.5 C 230.8 294.3, 226.9 295, 223.8 295 C 216.1 295, 214.6 298.5, 220.8 302.2 C 230.4 307.9, 231.6 317, 222.8 317 C 216.7 317, 216.8 322.3, 223.1 326.4 C 229.7 330.8, 231.1 335.2, 227.2 339.3 C 223.3 343.3, 223.3 344.5, 226.5 350.1 C 228.6 353.8, 229 355.8, 229 362.6 C 229 378.1, 224.6 376.1, 217.1 357.1 C 212 344.3, 211.6 342.3, 213.4 339.5 C 215.8 335.8, 215.3 333.1, 211.5 328.9 C 206.4 323.2, 205.9 320.2, 209.8 317 C 213.9 313.6, 213.9 313.3, 207.9 307.5 C 202.5 302.1, 200 298.3, 200 295.1 C 200 290.3, 192.5 285.6, 189.6 288.5 M 168.6 296 C 157 306.7, 159.2 329.4, 174.7 358.5 C 175.5 360.1, 178.5 365.8, 181.2 371 C 184 376.2, 186.6 381, 187 381.5 C 187.5 382.1, 191 388.6, 194.8 396 C 198.6 403.4, 203.5 412.4, 205.7 416 C 207.9 419.6, 211.2 425.2, 213 428.5 C 225 450.2, 236.4 463.4, 241 461 C 244.9 458.9, 244.1 457.1, 227 428.5 C 212.5 404.2, 210.3 400.1, 205.6 386.5 C 203.7 381, 200.3 371.3, 198 365 C 189.6 341.8, 185.7 327.6, 180.8 301.6 C 178.8 291.3, 175.4 289.8, 168.6 296 M 250 301.9 C 248.6 304.6, 248.7 370.5, 250.1 378.4 C 251.3 385.1, 253.9 397.3, 256.6 409 C 258.3 416.3, 266.1 436.5, 267.9 438.3 C 270.3 440.7, 272.2 438.1, 271.6 433.2 C 269 413.3, 267.7 343.9, 269.5 323.8 C 270.6 311.7, 270.2 310.9, 261.5 305 C 253.4 299.5, 251.6 299, 250 301.9';

function bird(faceW, faceH) {
  const scale = Math.min(faceW / BIRD_ART_W, faceH / BIRD_ART_H) * 0.82;
  const tx = (faceW - BIRD_ART_W * scale) / 2;
  const ty = (faceH - BIRD_ART_H * scale) / 2;
  const green = COLORS.sou;
  const red = COLORS.souAccent;
  const art =
    `<path d="${BIRD_GREEN_PATH}" fill="${green}" fill-rule="evenodd"/>` +
    `<path d="${BIRD_RED_PATH}" fill="${red}" fill-rule="evenodd"/>`;
  return (
    `<g transform="translate(${round(tx)},${round(ty)}) scale(${round(scale, 4)})">` +
    `<g transform="translate(${-BIRD_ART_OFFX},${-BIRD_ART_OFFY})">${art}</g>` +
    `</g>`
  );
}

// Place a stroke glyph centered horizontally in the face, in a square box of
// the given size with its top at `top`.
function centeredGlyph(name, faceW, top, size, color, weight) {
  return glyphSvg(name, (faceW - size) / 2, top, size, color, weight);
}

// The man numerals read a little light next to the heavy 萬, so give just them
// extra weight.
const MAN_NUMERAL_WEIGHT = 42;

// Draw the symbol layer for a tile onto its face box (origin at face top-left).
function faceContent(tile, opt) {
  const { width: faceW, height: faceH } = opt;
  const padX = faceW * 0.14;
  const padY = faceH * 0.13;
  const innerW = faceW - padX * 2;
  const innerH = faceH - padY * 2;
  const cx = faceW / 2;
  const cy = faceH / 2;

  switch (tile.suit) {
    case 'man': {
      const numColor = tile.red ? COLORS.manKanji : COLORS.manNum;
      return (
        centeredGlyph(tile.value, faceW, faceH * 0.1, faceW * 0.46, numColor, MAN_NUMERAL_WEIGHT) +
        centeredGlyph('wan', faceW, faceH * 0.44, faceW * 0.6, COLORS.manKanji)
      );
    }
    case 'pin': {
      if (tile.value === 1) return flowerPip(cx, cy, Math.min(innerW, innerH) * 0.5);
      const pts = pinLayout(tile.value);
      const r = Math.min(innerW, innerH) / (tile.value <= 4 ? 5 : tile.value <= 6 ? 5.6 : 7);
      const colors = pinColors(tile.value);
      return pts
        .map(([fx, fy], idx) => {
          const color = tile.red ? COLORS.pin[2] : colors[idx] || COLORS.pin[0];
          return circlePip(padX + fx * innerW, padY + fy * innerH, r, color);
        })
        .join('');
    }
    case 'sou': {
      if (tile.value === 1) return bird(faceW, faceH);
      if (tile.value === 8) return souEight(padX, padY, innerW, innerH, COLORS.sou);
      const pts = souLayout(tile.value);
      const w = innerW / (tile.value <= 4 ? 6 : tile.value <= 6 ? 7.2 : 8.5);
      const h = innerH / (tile.value <= 3 ? 2.3 : tile.value <= 6 ? 2.8 : 3.4);
      return pts
        .map(([fx, fy], idx) => {
          // Red accents: the 5's center stick, the 7's lone top stick, and the
          // 9's middle column (indices 1, 4, 7 in row-major order).
          const isAccent =
            (tile.value === 7 && idx === 0) ||
            (tile.value === 5 && idx === 2) ||
            (tile.value === 9 && idx % 3 === 1);
          const color = tile.red || isAccent ? COLORS.souAccent : COLORS.sou;
          return bambooStick(padX + fx * innerW, padY + fy * innerH, w, h, color);
        })
        .join('');
    }
    case 'wind': {
      const size = faceW * 0.72;
      return centeredGlyph(tile.value, faceW, (faceH - size) / 2, size, COLORS.wind);
    }
    case 'dragon': {
      if (tile.value === 'white') {
        // White dragon (Haku): a blank white tile.
        return '';
      }
      const color = tile.value === 'red' ? COLORS.dragonRed : COLORS.dragonGreen;
      const size = faceW * 0.66;
      return centeredGlyph(tile.value, faceW, (faceH - size) / 2, size, color);
    }
    default:
      return '';
  }
}

// The face-down side: a green back with vertical ribbing that fills the face
// edge to edge, after the classic two-tone tile (white body, ribbed green back).
// The ribs run the full width and height and are clipped to the rounded face, so
// they fill the corners instead of stopping short of them.
function backFace(opt, clipId) {
  if (!opt.backRibs) return '';
  const { width: faceW, height: faceH, radius } = opt;
  const clip =
    `<clipPath id="${clipId}">` +
    `<rect x="0" y="0" width="${faceW}" height="${faceH}" rx="${radius}"/>` +
    `</clipPath>`;
  const sw = round(faceW * 0.045); // rib thickness
  // Pitch ~2x the thickness gives roughly even rib/groove coverage. Density
  // stays consistent regardless of tile size.
  const ribs = Math.max(2, Math.round(faceW / (sw * 2)));
  const step = faceW / ribs;
  let lines = '';
  for (let idx = 0; idx < ribs; idx++) {
    const x = round(step * (idx + 0.5));
    lines +=
      `<line x1="${x}" y1="0" x2="${x}" y2="${faceH}" ` +
      `stroke="${opt.backRibColor}" stroke-width="${sw}" opacity="0.5"/>`;
  }
  return `<defs>${clip}</defs><g clip-path="url(#${clipId})">${lines}</g>`;
}

// Build the tile body (face + faux-3D side) at the origin.
function tileBody(opt, gradientId) {
  const { width: faceW, height: faceH, radius, depth } = opt;
  const isBack = opt._back;
  const faceTop = isBack ? opt.backColorTop : opt.faceColorTop;
  const faceBottom = isBack ? opt.backColor : opt.faceColor;

  const side =
    depth > 0
      ? `<rect x="${round(depth * 0.5)}" y="${round(depth * 0.7)}" width="${faceW}" height="${faceH}" ` +
        `rx="${radius}" fill="${isBack ? opt.sideShadow : opt.sideColor}"/>`
      : '';

  const face =
    `<rect x="0" y="0" width="${faceW}" height="${faceH}" rx="${radius}" ` +
    `fill="url(#${gradientId})" stroke="${isBack ? opt.backColor : opt.edgeColor}" stroke-width="1"/>`;

  const grad =
    `<linearGradient id="${gradientId}" x1="0" y1="0" x2="0" y2="1">` +
    `<stop offset="0" stop-color="${faceTop}"/>` +
    `<stop offset="1" stop-color="${faceBottom}"/>` +
    `</linearGradient>`;

  return { grad, side, face };
}

// Merge caller options over the defaults, plus cross-option defaults that can't
// be expressed statically.
function resolveOptions(options) {
  const opt = { ...DEFAULTS, ...options };
  // The face-up 3-D edge shows the tile's back; keep it in sync with backColor
  // unless the caller set sideColor explicitly.
  if (options.sideColor === undefined) opt.sideColor = opt.backColor;
  return opt;
}

// Opening tag for a root <svg>. By default it carries fixed px width/height; with
// `opt.fit` it uses width/height="100%" so the viewBox scales the tile to fill its
// container — no `& > svg { width:100% }` CSS needed on the consumer side.
function svgOpen(opt, totalW, totalH, label) {
  const size = opt.fit
    ? 'width="100%" height="100%"'
    : `width="${round(totalW)}" height="${round(totalH)}"`;
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" ${size} ` +
    `viewBox="0 0 ${round(totalW)} ${round(totalH)}" role="img" aria-label="${esc(label)}">`
  );
}

let gradCounter = 0;

/**
 * Render a single tile to a standalone SVG string.
 * @param {string|object} tile - notation ("5p", "E", "rd") or a tile object.
 * @param {object} [options]
 * @returns {string} SVG markup
 */
export function tileToSvg(tile, options = {}) {
  const parsed = parseTile(tile);
  const opt = resolveOptions(options);
  const totalW = opt.width + opt.depth;
  const totalH = opt.height + opt.depth;
  const inner = renderTileGroup(parsed, opt, 0, 0);
  return (
    svgOpen(opt, totalW, totalH, tileLabel(parsed)) +
    (opt.background ? `<rect width="100%" height="100%" fill="${opt.background}"/>` : '') +
    inner +
    `</svg>`
  );
}

// Render one tile as a <g> placed at (x, y) within a larger svg.
function renderTileGroup(tile, options, x, y) {
  const opt = { ...options, _back: tile.suit === 'back' };
  const gradientId = `tk-grad-${gradCounter++}`;
  const { grad, side, face } = tileBody(opt, gradientId);
  const content = opt._back
    ? backFace(opt, gradientId.replace('grad', 'clip'))
    : faceContent(tile, opt);
  return (
    `<g transform="translate(${round(x)},${round(y)})">` +
    `<defs>${grad}</defs>` +
    side +
    face +
    content +
    `</g>`
  );
}

// Suit nouns as [singular, plural]; bamboo is uncountable so both are the same.
const SUIT_NOUNS = {
  man: ['character', 'characters'],
  pin: ['circle', 'circles'],
  sou: ['bamboo', 'bamboo'],
};

function tileLabel(tile) {
  const parsed = parseTile(tile); // accepts notation ("5z") or a parsed tile object
  if (parsed.suit === 'back') return 'face-down tile';
  if (parsed.suit === 'wind') return `${parsed.value} wind`;
  if (parsed.suit === 'dragon') return `${parsed.value} dragon`;
  const [singular, plural] = SUIT_NOUNS[parsed.suit];
  const noun = parsed.value === 1 ? singular : plural;
  return `${parsed.red ? 'red ' : ''}${parsed.value} ${noun}`;
}

/**
 * Render a row of tiles (a hand) to a single SVG string.
 * @param {string|string[]|object[]} hand - notation or tile objects.
 * @param {object} [options]
 * @returns {string} SVG markup
 */
export function handToSvg(hand, options = {}) {
  const opt = resolveOptions(options);
  const tiles = normalizeHand(hand);
  if (tiles.length === 0) {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0"></svg>`;
  }
  const stepX = opt.width + opt.depth + opt.gap;
  const totalW = stepX * tiles.length - opt.gap;
  const totalH = opt.height + opt.depth;

  const groups = tiles
    .map((tile, idx) => renderTileGroup(tile, opt, idx * stepX, 0))
    .join('');

  return (
    svgOpen(opt, totalW, totalH, tiles.map(tileLabel).join(', ')) +
    (opt.background ? `<rect width="100%" height="100%" fill="${opt.background}"/>` : '') +
    groups +
    `</svg>`
  );
}

function normalizeHand(hand) {
  if (Array.isArray(hand)) {
    return hand.map((entry) => parseTile(entry));
  }
  // String hands are parsed via the notation module.
  return parseHand(hand);
}

export { tileLabel, DEFAULTS };
