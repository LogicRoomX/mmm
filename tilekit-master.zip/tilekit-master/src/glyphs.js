// CJK character glyphs for mahjong tiles.
//
// tilekit composes the tiles (bodies, circle/bamboo layouts, colors); the
// calligraphic character outlines themselves come from `hanzi-writer-data` at
// runtime — real Kai-style filled strokes rather than hand-drawn approximations.
// We deliberately depend on that data rather than vendor it in.
//
// The data is derived from the Make Me a Hanzi project and licensed under the
// Arphic Public License (see node_modules/hanzi-writer-data/ARPHICPL.TXT).
//
// Each character file exposes `strokes`: an array of SVG path strings drawn in a
// 1024-unit em with the y-axis pointing up and the baseline at y=900, so we map
// it into our top-left box with `translate(0,900) scale(1,-1)`.
import one from 'hanzi-writer-data/一.json' with { type: 'json' };
import two from 'hanzi-writer-data/二.json' with { type: 'json' };
import three from 'hanzi-writer-data/三.json' with { type: 'json' };
import four from 'hanzi-writer-data/四.json' with { type: 'json' };
import five from 'hanzi-writer-data/伍.json' with { type: 'json' };
import six from 'hanzi-writer-data/六.json' with { type: 'json' };
import seven from 'hanzi-writer-data/七.json' with { type: 'json' };
import eight from 'hanzi-writer-data/八.json' with { type: 'json' };
import nine from 'hanzi-writer-data/九.json' with { type: 'json' };
import wan from 'hanzi-writer-data/萬.json' with { type: 'json' };
import east from 'hanzi-writer-data/東.json' with { type: 'json' };
import south from 'hanzi-writer-data/南.json' with { type: 'json' };
import west from 'hanzi-writer-data/西.json' with { type: 'json' };
import north from 'hanzi-writer-data/北.json' with { type: 'json' };
import green from 'hanzi-writer-data/發.json' with { type: 'json' };
import red from 'hanzi-writer-data/中.json' with { type: 'json' };

// Map tilekit's internal glyph names to character data.
const GLYPHS = {
  1: one, 2: two, 3: three, 4: four, 5: five, 6: six, 7: seven, 8: eight, 9: nine,
  wan, east, south, west, north, green, red,
};

const EM = 1024;
const BASELINE = 900;
// Glyphs are filled outlines; stroking each path in its own fill color expands
// the shapes outward, making the characters heavier. Units are em (1024).
const WEIGHT = 26;

function round(num, places = 3) {
  const factor = 10 ** places;
  return Math.round(num * factor) / factor;
}

/**
 * Render a glyph as an SVG fragment scaled into a size x size box at (x, y).
 * @param {string|number} name - key in GLYPHS
 * @param {number} x - left of the glyph box
 * @param {number} y - top of the glyph box
 * @param {number} size - box side length
 * @param {string} color - fill color
 * @param {number} [weight] - extra stroke weight in em units (default WEIGHT)
 * @returns {string} SVG markup ('' if the glyph is unknown)
 */
export function glyphSvg(name, x, y, size, color, weight = WEIGHT) {
  const glyph = GLYPHS[name];
  if (!glyph) return '';
  const scale = size / EM;
  const d = glyph.strokes.join(' ');
  return (
    `<g transform="translate(${round(x)},${round(y)}) scale(${round(scale, 5)}) ` +
    `translate(0,${BASELINE}) scale(1,-1)" fill="${color}">` +
    `<path d="${d}" stroke="${color}" stroke-width="${weight}" ` +
    `stroke-linejoin="round" stroke-linecap="round"/></g>`
  );
}

export { GLYPHS };
