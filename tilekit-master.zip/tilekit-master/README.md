[![npm version](https://img.shields.io/npm/v/tilekit.svg?logo=npm)](https://www.npmjs.com/package/tilekit)

# tilekit

Render mahjong tiles to **SVG**. Works in Node and the browser.

`tilekit` turns compact mahjong notation (`123m`, `5z`, `0p`) into clean,
scalable SVG — single tiles or whole hands. Output is plain markup, so you can
drop it into a webpage, save it to a file, or pipe it into a PNG converter.

![Seven-pairs winning hand: 11m 99m 0p5p 11s 77s 11z 5z back](https://raw.githubusercontent.com/csimi/tilekit/master/examples/hand.png)

tilekit composes the tiles themselves — bodies, the circle/bamboo suit art (the
1 of bamboo is a stylized crested bird in folk two-tone style), colors, and layout. The calligraphic character outlines (一-九, 萬, 東南西北,
發, 中) come from [`hanzi-writer-data`](https://github.com/chanind/hanzi-writer-data)
at runtime as real Kai-style brush strokes, rather than being baked into this
package. That's tilekit's only dependency, and there is no `<text>` element, so
tiles render identically regardless of the fonts installed on the viewer's system.

## Install

```sh
npm install tilekit
```

## Quick start

```js
import { tileToSvg, handToSvg, parseHand } from 'tilekit';

// A single tile
const five = tileToSvg('5p');           // five of circles

// A whole hand
const svg = handToSvg('123m456p789s11z'); // pure markup string

// Inspect parsed tiles
parseHand('0p E rd');
// [
//   { suit: 'pin',    value: 5,      red: true,  code: '0p' },
//   { suit: 'wind',   value: 'east', red: false, code: '1z' },
//   { suit: 'dragon', value: 'red',  red: false, code: '7z' },
// ]
```

### In the browser

```js
import { handToSvg } from 'tilekit';
document.querySelector('#hand').innerHTML = handToSvg('234m234p234s');
```

### In Node — save to a file

```js
import { writeFileSync } from 'node:fs';
import { handToSvg } from 'tilekit';
writeFileSync('hand.svg', handToSvg('123m456p789s11z', { background: '#0b3d2e' }));
```

## Notation

`tilekit` uses the standard riichi / tenhou compact notation. Tokens may be
written contiguously (`123m456p`) or separated by spaces.

| Notation        | Meaning                                             |
| --------------- | --------------------------------------------------- |
| `1m`-`9m`       | characters (man / 萬)                               |
| `1p`-`9p`       | circles (pin / 筒)                                  |
| `1s`-`9s`       | bamboo (sou / 索)                                   |
| `0m` `0p` `0s`  | red five of that suit (aka dora)                    |
| `1z`-`4z`       | winds: East, South, West, North                     |
| `5z`-`7z`       | dragons: White, Green, Red                          |
| `E` `S` `W` `N` | wind aliases                                        |
| `wd` `gd` `rd`  | dragon aliases (white / green / red)                |
| `back`          | a face-down tile                                    |

The `E S W N` and `wd gd rd` aliases are case-insensitive (`e`, `WD`, etc. all
work), but unlike suited runs they must be separated by spaces - write winds
contiguously as `1234z` rather than `eswn`.

So `123m0p789p11s55z back` is one, two, three of characters; a red five and
seven-eight-nine of circles; a pair of one-bamboo; a pair of white dragons; and
a face-down tile.

## API

### `tileToSvg(tile, options?) → string`

Render a single tile to a standalone SVG string. `tile` is either notation
(`"5p"`, `"E"`, `"rd"`) or a tile object from `parseHand`/`parseTile`.

### `handToSvg(hand, options?) → string`

Render a row of tiles to a single SVG string. `hand` is a notation string, an
array of notation tokens, or an array of tile objects.

### `parseHand(input) → Tile[]` / `parseTile(input) → Tile`

Parse notation into structured tile objects without rendering.

### `tileLabel(tile) → string`

Human-readable name for a tile — `"5 circles"`, `"white dragon"`, `"east wind"`,
`"red 5 circles"`, `"face-down tile"`. Accepts notation (`"5z"`) or a tile object.

### Options

All options are optional; defaults shown.

| Option         | Default     | Description                              |
| -------------- | ----------- | ---------------------------------------- |
| `width`        | `60`        | Face width in px                         |
| `height`       | `80`        | Face height in px                        |
| `radius`       | `8`         | Corner radius in px                      |
| `depth`        | `4`         | Faux-3D thickness on the bottom/right    |
| `gap`          | `6`         | Spacing between tiles in a hand          |
| `backRibs`     | `true`      | Draw vertical ribbing on face-down (back) tiles |
| `backColor`    | `#6f9b3e`   | Face-down back base color (bottom of gradient) |
| `backColorTop` | `#7faa49`   | Face-down back highlight (top of gradient) |
| `backRibColor` | `#587d2e`   | Color of the back's vertical ribbing     |
| `fit`          | `false`     | Root `<svg>` uses `width`/`height="100%"` (scales via viewBox) |
| `background`   | `null`      | SVG background fill (null = transparent) |
| `faceColor`    | `#fbf7ec`   | Tile face base color                     |
| `faceColorTop` | `#fffefa`   | Tile face highlight (top of gradient)    |
| `edgeColor`    | `#cdbf9f`   | Border color                             |
| `sideColor`    | `backColor` | Back color shown along a face-up tile's 3-D edge (follows `backColor`) |
| `sideShadow`   | `#587d2e`   | A face-down (back) tile's own 3-D edge color |

## CLI

A small CLI is bundled for quick rendering:

```sh
npx tilekit "123m456p789s11z" -o hand.svg
npx tilekit "E S W N" --background "#0b3d2e" > winds.svg
```

Flags: `-o/--out`, `--width`, `--height`, `--background`.

## Examples

`npm run example` writes a set of sample SVGs to `examples/` (and a PNG of the
example hand above, used in this README).

## Credits

Character glyphs are provided at runtime by
[`hanzi-writer-data`](https://github.com/chanind/hanzi-writer-data), whose stroke
data is derived from the [Make Me a Hanzi](https://github.com/skishore/makemeahanzi)
project and the Arphic Kai fonts, distributed under the
[Arphic Public License](https://github.com/chanind/hanzi-writer-data/blob/master/ARPHICPL.TXT).

## License

ISC © David Csirmaz
