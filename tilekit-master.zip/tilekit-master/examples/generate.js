// Generate sample SVGs into examples/.
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { tileToSvg, handToSvg, parseHand } from '../src/index.js';

const outDir = dirname(fileURLToPath(import.meta.url));

function save(name, svg) {
  const file = join(outDir, name);
  writeFileSync(file, svg, 'utf8');
  console.log('wrote', file);
}

// A full suit of each type.
save('man.svg', handToSvg('123456789m', { background: '#0b3d2e' }));
save('pin.svg', handToSvg('123456789p', { background: '#0b3d2e' }));
save('sou.svg', handToSvg('123456789s', { background: '#0b3d2e' }));
save('honors.svg', handToSvg('1234567z', { background: '#0b3d2e' }));

// Seven pairs (chiitoitsu): a complete winning hand with a red five, won on the face-down tile.
// No background so the generated hand.png is transparent.
save('hand.svg', handToSvg('11m 99m 0p5p 11s 77s 11z 5z back'));

// Red fives (aka dora): 0m / 0p / 0s, next to their normal counterparts.
save('red-fives.svg', handToSvg('0m 5m 0p 5p 0s 5s', { background: '#0b3d2e' }));

// Single tiles.
for (const tile of parseHand('1s 5z 5m')) {
  save(`tile-${tile.code}.svg`, tileToSvg(tile));
}

console.log('done');
