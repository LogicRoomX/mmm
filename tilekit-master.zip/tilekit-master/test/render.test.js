import { test } from 'node:test';
import assert from 'node:assert/strict';
import { tileToSvg, handToSvg, tileLabel } from '../src/render.js';
import { parseTile } from '../src/notation.js';

function isWellFormedSvg(svg) {
  assert.match(svg, /^<svg[\s>]/);
  assert.match(svg, /<\/svg>$/);
  // Balanced <g> tags.
  const open = (svg.match(/<g[\s>]/g) || []).length;
  const close = (svg.match(/<\/g>/g) || []).length;
  assert.equal(open, close, 'unbalanced <g> tags');
}

test('renders every suited tile', () => {
  for (const suit of ['m', 'p', 's']) {
    for (let value = 1; value <= 9; value++) {
      const svg = tileToSvg(`${value}${suit}`);
      isWellFormedSvg(svg);
    }
  }
});

test('renders all honors and back', () => {
  for (const code of ['1z', '2z', '3z', '4z', '5z', '6z', '7z', 'back']) {
    isWellFormedSvg(tileToSvg(code));
  }
});

test('red fives render in every suit and differ from normal fives', () => {
  const red = '#a01f28';
  for (const suit of ['m', 'p', 's']) {
    const redFive = tileToSvg(`0${suit}`);
    const normalFive = tileToSvg(`5${suit}`);
    isWellFormedSvg(redFive);
    assert.notEqual(redFive, normalFive, `0${suit} should differ from 5${suit}`);
    assert.ok(redFive.includes(red), `0${suit} should use the red accent color`);
  }
});

test('svg dimensions reflect options', () => {
  const svg = tileToSvg('5m', { width: 100, height: 140, depth: 0 });
  assert.match(svg, /width="100"/);
  assert.match(svg, /height="140"/);
});

test('hand renders all tiles side by side', () => {
  const svg = handToSvg('123m456p789s11z');
  isWellFormedSvg(svg);
  // 11 tiles -> 11 translate groups for tiles (plus none extra at top level).
  const translates = (svg.match(/translate\(/g) || []).length;
  assert.ok(translates >= 11);
});

test('empty hand yields empty svg', () => {
  const svg = handToSvg('');
  assert.match(svg, /<svg/);
});

test('background option adds a rect', () => {
  const svg = handToSvg('E', { background: '#0b3d2e' });
  assert.match(svg, /fill="#0b3d2e"/);
});

test('aria-label describes the tiles', () => {
  assert.match(tileToSvg('0s'), /aria-label="red 5 bamboo"/);
  assert.match(tileToSvg('1z'), /aria-label="east wind"/);
});

test('aria-label singularizes the suit noun for a single tile', () => {
  assert.match(tileToSvg('1m'), /aria-label="1 character"/);
  assert.match(tileToSvg('1p'), /aria-label="1 circle"/);
  assert.match(tileToSvg('2p'), /aria-label="2 circles"/);
  assert.match(tileToSvg('1s'), /aria-label="1 bamboo"/);
});

test('tileLabel names every tile category', () => {
  assert.equal(tileLabel('1m'), '1 character');
  assert.equal(tileLabel('9m'), '9 characters');
  assert.equal(tileLabel('1p'), '1 circle');
  assert.equal(tileLabel('5p'), '5 circles');
  assert.equal(tileLabel('1s'), '1 bamboo');
  assert.equal(tileLabel('3s'), '3 bamboo');
  assert.equal(tileLabel('0p'), 'red 5 circles');
  assert.equal(tileLabel('1z'), 'east wind');
  assert.equal(tileLabel('4z'), 'north wind');
  assert.equal(tileLabel('5z'), 'white dragon');
  assert.equal(tileLabel('6z'), 'green dragon');
  assert.equal(tileLabel('7z'), 'red dragon');
  assert.equal(tileLabel('back'), 'face-down tile');
});

test('tileLabel accepts notation strings or parsed tile objects', () => {
  assert.equal(tileLabel('5z'), tileLabel(parseTile('5z')));
  assert.equal(tileLabel(parseTile('0s')), 'red 5 bamboo');
});

test('output escapes nothing dangerous and stays valid xml-ish', () => {
  const svg = handToSvg('1234567z');
  assert.ok(!svg.includes('undefined'));
  assert.ok(!svg.includes('NaN'));
});
