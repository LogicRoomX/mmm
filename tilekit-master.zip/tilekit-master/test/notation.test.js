import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseHand, parseTile } from '../src/notation.js';

test('parses a compact suited run', () => {
  const tiles = parseHand('123m');
  assert.equal(tiles.length, 3);
  assert.deepEqual(
    tiles.map((tile) => tile.code),
    ['1m', '2m', '3m']
  );
  assert.equal(tiles[0].suit, 'man');
});

test('parses mixed suits contiguously', () => {
  const tiles = parseHand('123m456p789s');
  assert.equal(tiles.length, 9);
  assert.deepEqual(tiles[3], { suit: 'pin', value: 4, red: false, code: '4p' });
  assert.equal(tiles[8].suit, 'sou');
});

test('red five via 0', () => {
  const [tile] = parseHand('0p');
  assert.equal(tile.value, 5);
  assert.equal(tile.red, true);
  assert.equal(tile.code, '0p');
});

test('honors via z-notation', () => {
  const tiles = parseHand('1234567z');
  assert.deepEqual(
    tiles.map((tile) => tile.value),
    ['east', 'south', 'west', 'north', 'white', 'green', 'red']
  );
  assert.equal(tiles[0].suit, 'wind');
  assert.equal(tiles[4].suit, 'dragon');
});

test('honor aliases', () => {
  const tiles = parseHand('E S W N wd gd rd');
  assert.deepEqual(
    tiles.map((tile) => tile.value),
    ['east', 'south', 'west', 'north', 'white', 'green', 'red']
  );
});

test('back tile', () => {
  const [tile] = parseHand('back');
  assert.equal(tile.suit, 'back');
});

test('spaces are optional and ignored', () => {
  assert.equal(parseHand('11m 99p').length, parseHand('11m99p').length);
});

test('array input flattens', () => {
  const tiles = parseHand(['11m', 'E']);
  assert.equal(tiles.length, 3);
});

test('parseTile returns single tile', () => {
  assert.equal(parseTile('5s').suit, 'sou');
  assert.throws(() => parseTile('12m'));
});

test('rejects invalid tokens and honor values', () => {
  assert.throws(() => parseHand('8z'));
  assert.throws(() => parseTile('Xy'));
});

test('empty input', () => {
  assert.deepEqual(parseHand(''), []);
  assert.deepEqual(parseHand('   '), []);
});
