'use strict';
const assert=require('assert');
const {absorb}=require('../src/absorb_source');
const {svgForTile,countNodes}=require('../src/render_library');

const counts=[24,7,10,13,16,19,22,25,28,13,3,4,5,6,7,8,9,10,3,3,3,3,3,3,3,3,3,2,2,2,2,7,2,2,9,12,6,22,18,8,16,18];
const manifest=require('../config/page_manifest.json');
const settings=require('../settings.json');
function fixtureSvg(){
  let pathNo=0;
  const pages=[];
  const elements=[];
  const step=1153.8587, w=1133.8586, h=1511.8134;
  for(let i=0;i<42;i++){
    const n=i+1,x=i*step;
    pages.push(`<inkscape:page x="${x}" y="0" inkscape:label="${n}" id="page${n}" width="${w}" height="${h}" />`);
    for(let j=0;j<counts[i];j++){
      pathNo++;
      const id=`path${pathNo}`;
      const isOutline=j===0;
      let fill='none',stroke='none';
      if(isOutline) stroke='#221815';
      else if(n>=19&&n<=27) fill=j===1?'#2926a5':'#d11228';
      else if(n>=35&&n<=38) fill=manifest.legacy_flower_marker_source_ids.includes(id)?'#2926a5':(j%3===0?'#d11228':'#21983a');
      else if(n>=39&&n<=42) fill=manifest.legacy_flower_marker_source_ids.includes(id)?'#d11228':(j%3===0?'#d11228':'#21983a');
      else if(n>=10&&n<=18) fill='#21983a';
      else if(n>=28&&n<=31) fill='#2926a5';
      else if(n>=32&&n<=34) fill=n===32?'#2f6eb6':(n===33?'#d11228':'#21983a');
      else fill=j%2?'#1f489b':'#21983a';
      const e=isOutline?x+1040:x+250+(j%5)*125;
      const f=isOutline?1300:250+((j*97)%900);
      const style=`fill:${fill};stroke:${stroke};stroke-width:${isOutline?1:2};stroke-linecap:round`;
      const d=isOutline?'M0 0 C0 -26 -21 -48 -47 -48 L-662 -48 C-688 -48 -709 -26 -709 0 L-709 839 C-709 866 -688 887 -662 887 L-47 887 C-21 887 0 866 0 839 Z':'M0 0 C-18 -20 -18 -50 0 -60 C18 -50 18 -20 0 0 Z';
      elements.push(`<path id="${id}" d="${d}" transform="matrix(1.3333333 0 0 -1.3333333 ${e} ${f})" style="${style}" />`);
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"><sodipodi:namedview>${pages.join('')}</sodipodi:namedview><g>${elements.join('')}</g></svg>`;
}
function main(){
  assert.strictEqual(counts.reduce((a,b)=>a+b,0),384);
  const lib=absorb(fixtureSvg(),manifest,settings);
  assert.strictEqual(lib.tiles.length,42);
  assert.strictEqual(lib.path_index.length,384);
  assert.strictEqual(lib.component_definitions.length>=1,true);
  assert.strictEqual(lib.tiles.reduce((n,t)=>n+t.legacy_marker_count,0),8);
  const crak=lib.tiles.find(t=>t.tile_id==='crak-02');
  const crakContent=crak.root.children.find(g=>g.id==='tile-content');
  assert(crakContent.children.some(g=>g.id==='rank-glyph'));
  assert(crakContent.children.some(g=>g.id==='wan-symbol'));
  const flower=lib.tiles.find(t=>t.tile_id==='flower-01');
  const content=flower.root.children.find(g=>g.id==='tile-content');
  assert(content.children.some(g=>g.id==='legacy-index-marker'&&g.visible===false));
  assert(content.children.some(g=>g.id==='botanical-composition'));
  const dot2=lib.tiles.find(t=>t.tile_id==='dot-02');
  assert.deepStrictEqual(lib.semantic_statistics.dot_cluster_sizes['dot-02'],[3,3]);
  const compMap=new Map(lib.component_definitions.map(c=>[c.component_id,c]));
  const svg=svgForTile(flower,compMap,{...settings,tile_outline:{...settings.tile_outline,width:10}});
  assert(svg.includes('id="tile-outline"'));
  assert(svg.includes('id="tile-content"'));
  assert(svg.includes('display="none"'));
  assert(svg.includes('stroke-width:10'));
  assert.strictEqual(countNodes(flower.root).paths,counts[34]);
  console.log("Synthetic test passed. Pipeline structure validated; real source visuals still require the user's local absorb run.");
}
if (require.main===module) { try{main()}catch(e){console.error(e.stack||e);process.exitCode=1} }
module.exports={fixtureSvg,counts};
