@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
set "LOG=%~dp0logs\render_from_library.log"
set "RC=0"
(
  echo American Mahjong Asset Studio v0.3.1 - render from library
  echo Started: %DATE% %TIME%
  echo Project folder: %~dp0
  where.exe node
  node --version
) >"%LOG%" 2>&1
where.exe node >nul 2>&1
if errorlevel 1 (
  set "RC=9009"
  >>"%LOG%" echo ERROR: Node.js was not found in PATH.
  goto :finish
)
node "%~dp0src\verify_library.js" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto :finish
node "%~dp0src\render_library.js" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
:finish
echo.
echo ================================================
echo Render from asset library - result
echo ================================================
echo Exit code: %RC%
echo Log file: %LOG%
echo.
if exist "%LOG%" type "%LOG%"
echo.
if "%RC%"=="0" (
  echo Render completed. Press any key to open the preview.
  pause >nul
  if exist "%~dp0output\preview.html" start "" "%~dp0output\preview.html"
) else (
  echo FAILED. Please send logs\render_from_library.log for diagnosis.
  pause >nul
)
exit /b %RC%
