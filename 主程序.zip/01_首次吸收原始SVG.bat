@echo off
setlocal EnableExtensions
chcp 65001 >nul
call "%~dp0\01_FIRST_ABSORB.bat"
exit /b %ERRORLEVEL%
