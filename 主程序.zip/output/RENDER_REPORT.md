# 自包含资产渲染报告 v0.3

- 牌面：42
- 组件几何定义：356
- 重复几何组：24
- 隐藏但保留的花牌旧序号路径：8
- 原始 SVG 运行时依赖：无

## 输出

- preview.html：总览
- render_manifest.json：嵌套分组结构
- tiles/：42张独立SVG

每张牌的 SVG 都从资产库 JSON 的 path geometry + instance transforms/styles 重建。
