# American Mahjong Asset Studio v0.3.1

本版把目标从“拆分42个独立SVG”推进到“吸收原始SVG、建立自包含的嵌套矢量资产库”。v0.3.1 另修复 Windows 启动脚本的兼容性与错误日志显示。

## 这版最重要的变化

**原始 `无底.svg` 只在首次吸收时需要。**

首次运行会将所有原始 SVG path 的 `d` 几何数据、矩阵变换、颜色/描边样式、路径边界、来源 ID、组件引用和嵌套分组保存到：

```text
library/asset_library.json
```

后续 `render` 只读取这个 JSON，不读取 `input/无底.svg`。所以首次吸收成功并验证之后，可以把原始 SVG 移出项目；仍然可以重新生成每张牌的 SVG 和总览页面。

注意：这是一种无损保留原始路径几何的代码化资产封装，不是重新手工描摹。组件语义、布局及视觉简化会在此基础上继续迭代。

## 第一次运行

环境：Windows + Node.js 18 或更高版本。不需要 `npm install`，没有第三方依赖。

1. 解压项目。
2. 从 GitHub 下载原始 `无底.svg`，放入 `input` 文件夹。
3. 双击项目根目录中的 ASCII 文件名启动脚本：

```text
01_FIRST_ABSORB.bat
```

也可以双击中文快捷入口 `01_首次吸收原始SVG.bat`。v0.3.1 的批处理文件使用 ASCII 内容和 Windows CRLF 换行，避免 CMD 对 UTF-8 中文批处理内容的兼容性差异。

也可以在 PowerShell 项目目录中运行：

```powershell
node src/absorb_source.js
node src/verify_library.js
node src/render_library.js
```

首次吸收完成后，应出现：

```text
library/asset_library.json
```

请先确认验证通过、预览能打开，再把 `input/无底.svg` 移走。不要在验证之前删除原文件。


## v0.3.1 启动脚本诊断

如果双击后没有看到结果，请不要反复双击。新版启动脚本会把完整输出保存到：

- `logs/first_absorb.log`：首次吸收日志。
- `logs/render_from_library.log`：只使用资产库渲染的日志。

启动脚本运行结束后会停留在窗口中，并显示退出代码。若仍然无法运行，请把对应日志文件发回。

也可以先运行 `00_CHECK_NODE.bat` 检查 Node.js 是否已加入 PATH。要求 Node.js 18 或更新版本。

如果想手动排错，在项目根目录空白处打开 PowerShell，依次运行：

```powershell
node --version
Test-Path .\input\无底.svg
node .\src\absorb_source.js
```

如果第二行返回 `False`，说明原始 SVG 没有放在正确位置；应放在项目根目录下的 `input` 文件夹，完整路径为 `input\无底.svg`。

## 删除原始 SVG 后如何渲染

双击：

```text
02_RENDER_FROM_LIBRARY.bat
```

也可以使用中文快捷入口 `02_仅使用资产库渲染.bat`。

或者：

```powershell
node src/verify_library.js
node src/render_library.js
```

这两个命令只依赖 `library/asset_library.json` 和项目代码。它们不需要原始 SVG。

## 嵌套结构

每张牌的结构为：

```text
tile-{id}
├── tile-outline
└── tile-content
    ├── rank-glyph / wan-symbol           # Craks
    ├── dot-arrangement
    │   └── pip-01
    │       └── pip-ring-part × 3         # 每个筒点按源文件顺序三路径成组
    ├── bamboo-arrangement
    │   └── bamboo-stick-01               # Bams
    ├── wind-glyph                        # Winds
    ├── dragon-mark                       # Dragons
    └── botanical-composition             # Flowers
        ├── foliage
        ├── blossom
        ├── botanical-linework
        └── legacy-index-marker           # 隐藏但保留
```

所有 path 实例只保存组件 ID、变换和样式；实际 `d` 几何在 `component_definitions` 中集中保存。相同 `d` 的路径实例引用同一几何定义，但各自的颜色、位置和缩放仍可独立调整。

## 本轮自动整理规则

- 每张牌的原始3:4外轮廓成为独立 `tile-outline` 组。
- 牌框线宽默认设为10（源文件画板单位），颜色默认 `#221815`。可在 `settings.json` 修改。
- 2–9筒：当前源文件每一个可见筒点由连续3条路径构成；程序在路径数吻合 3×N 时按三条路径组成一个 `pip` 组件。若数量不匹配，会退回空间聚类并写入警告。
- 1筒特殊图案单独分组，不强行套用普通筒点结构。
- 1索的鸟按颜色层嵌套；2–9索按每条独立竹形路径拆为 `bamboo-stick` 实例。
- 万牌拆成上方 `rank-glyph` 和下方 `wan-symbol` 两个组。
- 风牌作为独立 `wind-glyph`；东牌提供一个初始光学右移参数，供预览验证。
- 龙牌保留原始构图并按颜色分层。
- 花牌旧数字/中文序号路径（源 path277、286、298、305、342、344、366、368）归档到隐藏的 `legacy-index-marker` 组，不在默认渲染中显示；路径仍在组件库里，没有被删除。
- 花牌其余图案按 `foliage`、`blossom`、`botanical-linework` 进行一级语义分组，并可水平居中。

上述语义分组是第一轮自动归类。原始路径几何会完整保留；特别是花卉中的枝叶、花瓣尚未全部细化到单叶/单瓣级，后续根据预览再精分。

## 输出

```text
library/
  asset_library.json       # 自包含数据；原始 SVG 的 path 几何已在这里
output/
  preview.html             # 42张牌总览
  render_manifest.json     # 每张牌的嵌套组清单
  RENDER_REPORT.md
  tiles/
    dots/
    bams/
    craks/
    winds/
    dragons/
    flowers/
```

## 设置

`settings.json`：

- `tile_outline.width`：牌面外轮廓宽度，当前默认10。
- `tile_outline.color`：牌面外轮廓颜色。
- `legacy_flower_markers.visible`：是否显示原花牌序号；默认为 false。
- `layout.center_flower_artwork_horizontally`：移除旧序号后是否将花卉主体水平居中。
- `layout.wind_01_optical_dx`：东字的初始光学右移量，当前22个源文件单位。以本地预览为准，可设为0或继续调整。
- `preview.card_shadow`：只影响预览网页的卡片投影，不会写入矢量母版。

## 校验与测试

```powershell
npm test
```

该测试使用合成 SVG 验证解析、42页/384路径约束、嵌套分组、8条旧花牌序号归档及从资产库渲染的流程。它不是对真实源 SVG 的视觉测试；真实素材必须由用户本地首次吸收后检查 `output/preview.html`。

首次吸收后可运行：

```powershell
node src/verify_library.js
```

## 文件与授权

`library/asset_library.json` 包含从原始 SVG 提取出的完整矢量路径数据，因此等同于保留这套图案素材。删除原始 SVG 不代表源图案版权限制消失。出版或商业使用前，仍需确认原始素材允许商业使用、修改和再分发。项目中的 MIT 许可仅适用于本工具代码，不适用于原始麻将图案。

## 源文件解析范围

针对当前仓库中的 `无底.svg` 已核对：文件有42个 Inkscape 画板、384个自闭合 `<path>` 元素；牌面路径使用 `matrix(a,b,c,d,e,f)` 变换；路径命令字母为 `M/m C/c H/h L/l V/v Z/z`，均由本版吸收器的边界分析器支持。路径原始 `d` 数据不会被重写。
