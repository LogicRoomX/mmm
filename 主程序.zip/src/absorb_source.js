'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  ROOT, readJson, writeJson, parseAttributes, parseStyle, parseMatrix,
  pathBounds, transformBounds, getTileMeta, clusterByCenter
} = require('./common');

const SOURCE_DEFAULT = path.join(ROOT, 'input', '无底.svg');
const MARKER_IDS = new Set([
  'path277', 'path286', 'path298', 'path305',
  'path342', 'path344', 'path366', 'path368'
]);

function parseSource(svgText) {
  const pages=[];
  const pageRe=/<inkscape:page\b([^>]*?)\/>/gs;
  let m;
  while ((m=pageRe.exec(svgText))!==null) {
    const a=parseAttributes(m[1]);
    const p={label:Number(a['inkscape:label'] || pages.length+1), id:a.id || `page${pages.length+1}`,
      x:Number(a.x||0), y:Number(a.y||0), width:Number(a.width||0), height:Number(a.height||0)};
    if (![p.label,p.x,p.y,p.width,p.height].every(Number.isFinite) || p.width<=0 || p.height<=0)
      throw new Error(`画板 ${a.id || pages.length+1} 的标签、坐标或尺寸无效。`);
    pages.push(p);
  }

  const paths=[];
  const pathRe=/<path\b([^>]*?)\/>/gs;
  let index=0;
  while ((m=pathRe.exec(svgText))!==null) {
    const a=parseAttributes(m[1]);
    const id=a.id || `path${++index}`;
    const matrix=parseMatrix(a.transform,id);
    const style=parseStyle(a.style||'');
    const d=a.d||'';
    if (!d) throw new Error(`路径 ${id} 没有 d 属性。`);
    const localBounds=pathBounds(d);
    const geometryHash=crypto.createHash('sha256').update(d).digest('hex');
    paths.push({id,d,matrix,style,fill:style.fill||'none',stroke:style.stroke||'none',
      geometryHash,localBounds,rawTransform:a.transform||''});
  }
  return {pages,paths};
}

function makePathNode(p, role, componentId, visible=true) {
  return {kind:'path', id:`${p.id}-${role}`, source_id:p.id, role, component_id:componentId,
    matrix:p.normalizedMatrix, style:p.style, fill:p.fill, stroke:p.stroke,
    bounds:p.bounds, visible};
}
function makeGroup(id, componentType, children, options={}) {
  return {kind:'group', id, component_type:componentType, visible:options.visible!==false,
    layout_transform:options.layout_transform||null, children};
}
function pathComponentType(p, category) {
  if (category==='dots') return 'pip-part';
  if (category==='bams') return 'bamboo-or-bird-part';
  if (category==='craks') return p.fill==='none'?'line-detail':'glyph-part';
  if (category==='winds') return 'wind-glyph-path';
  if (category==='dragons') return 'dragon-mark-path';
  if (category==='flowers') return 'botanical-part';
  return 'vector-path';
}
function byColor(paths) {
  const map=new Map();
  for (const p of paths) {
    const key=p.fill!=='none' ? `fill-${p.fill.replace('#','')}` : `stroke-${(p.stroke||'none').replace('#','')}`;
    if (!map.has(key)) map.set(key,[]);
    map.get(key).push(p);
  }
  return [...map.entries()];
}
function componentPathNodes(paths, componentIdByHash, role) {
  return paths.map(p=>makePathNode(p,role||pathComponentType(p,p.category),componentIdByHash.get(p.geometryHash)));
}

function buildTileTree(tile, page, pagePaths, componentIdByHash, settings, markerIds, semanticStats) {
  const outline=pagePaths.filter(p=>p.role==='tile-outline');
  const artwork=pagePaths.filter(p=>p.role!=='tile-outline');
  const outlineGroup=makeGroup('tile-outline','tile-outline',componentPathNodes(outline,componentIdByHash,'tile-outline'));
  const contentChildren=[];
  const cx=page.width/2;

  if (tile.category==='dots') {
    if (tile.number===1) {
      const blue=artwork.filter(p=>p.fill!=='none');
      const line=artwork.filter(p=>p.fill==='none');
      const red=blue.filter(p=>/^(#e51e28|#d11228)$/i.test(p.fill));
      const base=blue.filter(p=>!red.includes(p));
      contentChildren.push(makeGroup('dot-one-medallion','dot-medallion',[
        makeGroup('medallion-base','medallion-base',componentPathNodes(base,componentIdByHash,'medallion-base-part')),
        makeGroup('medallion-center','medallion-center',componentPathNodes(red,componentIdByHash,'medallion-center-part')),
        makeGroup('medallion-rosette','medallion-rosette',componentPathNodes(line,componentIdByHash,'rosette-line-part'))
      ]));
    } else {
      // In this source, each visible Dot pip is encoded as three consecutive concentric paths.
      // Use source order only when the expected 3×N structure matches; otherwise fall back to spatial clustering.
      let clusters;
      if (artwork.length===tile.number*3) {
        clusters=[];
        for (let i=0;i<artwork.length;i+=3) clusters.push(artwork.slice(i,i+3));
      } else {
        clusters=clusterByCenter(artwork,32);
        semanticStats.warnings=(semanticStats.warnings||[]).concat(`${tile.tile_id}: path count did not match 3×${tile.number}; used spatial fallback grouping.`);
      }
      const pips=clusters.map((cluster,i)=>makeGroup(`pip-${String(i+1).padStart(2,'0')}`,'dot-pip',
        componentPathNodes(cluster,componentIdByHash,'pip-ring-part')));
      contentChildren.push(makeGroup('dot-arrangement','dot-arrangement',pips));
      semanticStats.dot_cluster_sizes[tile.tile_id]=clusters.map(c=>c.length);
    }
  } else if (tile.category==='bams') {
    if (tile.number===1) {
      const layers=byColor(artwork).map(([key,items])=>makeGroup(`bird-${key}`,'bird-color-layer',
        componentPathNodes(items,componentIdByHash,'bird-part')));
      contentChildren.push(makeGroup('one-bam-bird','bird-emblem',layers));
    } else {
      const sticks=artwork.map((p,i)=>makeGroup(`bamboo-stick-${String(i+1).padStart(2,'0')}`,'bamboo-stick',
        [makePathNode(p,'bamboo-stick-path',componentIdByHash.get(p.geometryHash))]));
      contentChildren.push(makeGroup('bamboo-arrangement','bamboo-arrangement',sticks));
    }
  } else if (tile.category==='craks') {
    const blue=artwork.filter(p=>/^(#2926a5|#1f489b|#1a449a)$/i.test(p.fill));
    const red=artwork.filter(p=>/^(#d11228|#e51e28)$/i.test(p.fill));
    const other=artwork.filter(p=>!blue.includes(p)&&!red.includes(p));
    contentChildren.push(makeGroup('rank-glyph','rank-glyph',componentPathNodes(blue,componentIdByHash,'rank-glyph-path')));
    contentChildren.push(makeGroup('wan-symbol','wan-symbol',componentPathNodes(red,componentIdByHash,'wan-symbol-path')));
    if (other.length) contentChildren.push(makeGroup('crak-extra-detail','crak-extra-detail',componentPathNodes(other,componentIdByHash,'crak-detail')));
  } else if (tile.category==='winds') {
    const dx=tile.number===1 ? Number(settings.layout?.wind_01_optical_dx||0) : 0;
    const dy=tile.number===1 ? Number(settings.layout?.wind_01_optical_dy||0) : 0;
    const transform=(dx||dy)?{type:'translate',x:dx,y:dy}:null;
    contentChildren.push({...makeGroup('wind-glyph','wind-glyph',componentPathNodes(artwork,componentIdByHash,'wind-glyph-path'),{layout_transform:transform}),layout_key:tile.number===1?'wind_01_optical':null});
  } else if (tile.category==='dragons') {
    const dragonType=tile.number===1?'white-dragon-mark':tile.number===2?'red-dragon-glyph':'green-dragon-glyph';
    const children=byColor(artwork).map(([key,items])=>makeGroup(`dragon-${key}`,'dragon-color-layer',
      componentPathNodes(items,componentIdByHash,'dragon-symbol-part')));
    contentChildren.push(makeGroup(dragonType,dragonType,children));
  } else if (tile.category==='flowers') {
    const markers=artwork.filter(p=>markerIds.has(p.id));
    const botanical=artwork.filter(p=>!markerIds.has(p.id));
    if (markers.length) {
      contentChildren.push(makeGroup('legacy-index-marker','legacy-index-marker',
        componentPathNodes(markers,componentIdByHash,'legacy-flower-index'),{visible:settings.legacy_flower_markers?.visible===true}));
    }
    const green=botanical.filter(p=>/^#(21983a|39ae36|b3d796|2f6eb6)$/i.test(p.fill) || /^#(179e4b|21983a)$/i.test(p.stroke));
    const red=botanical.filter(p=>/^#(d11228|e51e28)$/i.test(p.fill) || /^#(d11228|e51e28)$/i.test(p.stroke));
    const other=botanical.filter(p=>!green.includes(p)&&!red.includes(p));
    const flowerChildren=[];
    flowerChildren.push(makeGroup('foliage','foliage',componentPathNodes(green,componentIdByHash,'foliage-part')));
    flowerChildren.push(makeGroup('blossom','blossom',componentPathNodes(red,componentIdByHash,'blossom-part')));
    if (other.length) flowerChildren.push(makeGroup('botanical-linework','botanical-linework',componentPathNodes(other,componentIdByHash,'botanical-linework-part')));
    const box=unionBounds(botanical.map(p=>p.bounds));
    let dx=0;
    if (box) dx=cx-box.cx;
    contentChildren.push({...makeGroup('botanical-composition','botanical-composition',flowerChildren,
      {layout_transform:dx?{type:'translate',x:dx,y:0}:null}),layout_key:'center_flower_artwork_x'});
  } else {
    contentChildren.push(makeGroup('unclassified-artwork','unclassified-artwork',componentPathNodes(artwork,componentIdByHash,'vector-path')));
  }

  return makeGroup(`tile-${tile.tile_id}`,'mahjong-tile',[
    outlineGroup,
    makeGroup('tile-content','tile-content',contentChildren)
  ]);
}
function unionBounds(boundsList) {
  const valid=boundsList.filter(Boolean);
  if (!valid.length) return null;
  const minX=Math.min(...valid.map(b=>b.x)), minY=Math.min(...valid.map(b=>b.y));
  const maxX=Math.max(...valid.map(b=>b.x+b.width)), maxY=Math.max(...valid.map(b=>b.y+b.height));
  return {x:minX,y:minY,width:maxX-minX,height:maxY-minY,cx:(minX+maxX)/2,cy:(minY+maxY)/2};
}

function absorb(svgText, manifest, settings) {
  const {pages,paths}=parseSource(svgText);
  if (pages.length!==42) throw new Error(`原始 SVG 应有42个画板，实际 ${pages.length} 个。`);
  if (paths.length!==384) throw new Error(`原始 SVG 应有384条 path，实际 ${paths.length} 条。`);

  const geometryMap=new Map();
  for (const p of paths) {
    if (!geometryMap.has(p.geometryHash)) geometryMap.set(p.geometryHash,p.d);
  }
  const componentIdByHash=new Map();
  const componentDefinitions=[];
  for (const [hash,d] of geometryMap.entries()) {
    const id=`geom-${hash.slice(0,12)}`;
    componentIdByHash.set(hash,id);
    componentDefinitions.push({component_id:id,geometry_sha256:hash,d,geometry_type:'svg-path'});
  }

  const tiles=[];
  const pathIndex=[];
  const markerIds=new Set(manifest.legacy_flower_marker_source_ids||[...MARKER_IDS]);
  const semanticStats={dot_cluster_sizes:{}};
  let assignedCount=0;

  for (const page of pages) {
    const pageNo=Number(page.label);
    const tile=getTileMeta(pageNo,manifest);
    const pagePaths=paths.filter(p=>p.matrix[4]>=page.x-0.001 && p.matrix[4]<page.x+page.width-0.001);
    if (!pagePaths.length) throw new Error(`第${pageNo}页没有匹配到路径。`);
    for (const p of pagePaths) {
      p.category=tile.category;
      p.bounds=transformBounds(p.localBounds,p.matrix,page);
      p.normalizedMatrix=[p.matrix[0],p.matrix[1],p.matrix[2],p.matrix[3],p.matrix[4]-page.x,p.matrix[5]-page.y];
      p.role=p.stroke.toLowerCase()==='#221815'?'tile-outline':(tile.category==='flowers'&&markerIds.has(p.id)?'legacy-flower-index':'artwork');
    }
    const outline=pagePaths.filter(p=>p.role==='tile-outline');
    if (outline.length!==1) throw new Error(`第${pageNo}页应有且只有1条外轮廓，实际 ${outline.length} 条。`);

    const tree=buildTileTree(tile,page,pagePaths,componentIdByHash,settings,markerIds,semanticStats);
    const markerCount=pagePaths.filter(p=>p.role==='legacy-flower-index').length;
    const tileRecord={...tile,source_page_id:page.id,width:page.width,height:page.height,
      viewBox:[0,0,page.width,page.height],source_path_count:pagePaths.length,
      artwork_path_count:pagePaths.length-1,outline_source_id:outline[0].id,
      legacy_marker_count:markerCount,root:tree};
    tiles.push(tileRecord);

    for (const p of pagePaths) {
      assignedCount++;
      pathIndex.push({tile_id:tile.tile_id,page:pageNo,source_path_id:p.id,
        role:p.role,component_id:componentIdByHash.get(p.geometryHash),
        geometry_sha256:p.geometryHash,fill:p.fill,stroke:p.stroke,
        bounds:p.bounds,source_matrix:p.matrix,normalized_matrix:p.normalizedMatrix});
    }
  }
  if (assignedCount!==paths.length) throw new Error(`路径分配数量不一致：${assignedCount}/${paths.length}。`);

  const repeated=new Map();
  for (const p of paths) {
    if (!repeated.has(p.geometryHash)) repeated.set(p.geometryHash,[]);
    repeated.get(p.geometryHash).push(p.id);
  }
  const sharedGeometry=[...repeated.entries()].filter(([,ids])=>ids.length>1)
    .map(([hash,ids])=>({component_id:componentIdByHash.get(hash),geometry_sha256:hash,instance_count:ids.length,source_path_ids:ids}));

  const library={
    schema:'american-mahjong-asset-library',schema_version:'0.3.0',
    source:{filename:'无底.svg',sha256:crypto.createHash('sha256').update(svgText).digest('hex'),
      absorbed_at:new Date().toISOString(),page_count:pages.length,path_count:paths.length,
      original_viewBox:'0 0 1133.8586 1511.8134',runtime_source_dependency:false},
    design_rules:{tile_aspect_ratio:'3:4',tile_outline_is_required:true,
      nested_group_model:'tile > tile-outline + tile-content > semantic component groups > editable vector path instances',
      shared_geometry_model:'component definitions store reusable path geometry; each tile keeps independent placement/style instances',
      legacy_flower_markers:'preserved in library, hidden by default'},
    component_definitions:componentDefinitions,
    shared_geometry:sharedGeometry,
    tiles,
    path_index:pathIndex,
    semantic_statistics:semanticStats
  };
  return library;
}

function main() {
  const settings=readJson('settings.json');
  const manifest=readJson('config/page_manifest.json');
  const sourcePath=path.resolve(ROOT,process.argv[2]||'input/无底.svg');
  if (!fs.existsSync(sourcePath)) {
    console.error(`找不到原始 SVG：${sourcePath}`);
    console.error('请把「无底.svg」放入项目 input 文件夹；成功吸收后，日常渲染不再需要它。');
    process.exitCode=2; return;
  }
  const text=fs.readFileSync(sourcePath,'utf8');
  const library=absorb(text,manifest,settings);
  writeJson('library/asset_library.json',library);
  const groupCount=library.shared_geometry.length;
  const markerCount=library.tiles.reduce((n,t)=>n+t.legacy_marker_count,0);
  console.log('SVG 吸收完成。');
  console.log(`  画板：${library.tiles.length}`);
  console.log(`  原始路径：${library.path_index.length}`);
  console.log(`  独立几何定义：${library.component_definitions.length}`);
  console.log(`  重复几何共享组：${groupCount}`);
  console.log(`  已识别并隐藏的旧花牌序号路径：${markerCount}`);
  console.log('  已生成 library/asset_library.json；后续 render 不再读取原始 SVG。');
}

if (require.main===module) {
  try { main(); } catch (err) { console.error('\n吸收失败：'+err.message); process.exitCode=1; }
}
module.exports={parseSource,absorb,buildTileTree,unionBounds};
