'use strict';

const fs = require('fs');
const path = require('path');
const { ROOT, readJson, ensureDir, escapeXml, fmt, serializeStyle } = require('./common');

function matrixString(m) {
  return `matrix(${m.map(fmt).join(' ')})`;
}
function renderNode(node, componentMap, settings) {
  if (node.kind==='path') {
    const geometry=componentMap.get(node.component_id);
    if (!geometry) throw new Error(`路径实例 ${node.source_id} 缺少组件几何 ${node.component_id}`);
    const style={...node.style};
    if (node.role==='tile-outline' && settings.tile_outline?.enabled) {
      style.stroke=settings.tile_outline.color || style.stroke || '#221815';
      const w=Number(settings.tile_outline.width);
      if (Number.isFinite(w)&&w>0) style['stroke-width']=String(w);
    }
    const pathId=`instance-${String(node.source_id).replace(/[^A-Za-z0-9_-]/g,'-')}`;
    return `<path id="${pathId}" d="${escapeXml(geometry.d)}" transform="${matrixString(node.matrix)}" style="${escapeXml(serializeStyle(style))}" data-source-id="${escapeXml(node.source_id)}" data-role="${escapeXml(node.role)}" data-component-id="${escapeXml(node.component_id)}" />`;
  }
  if (node.kind!=='group') throw new Error(`未知节点类型：${node.kind}`);
  const attrs=[];
  attrs.push(`id="${escapeXml(node.id)}"`);
  attrs.push(`data-component-type="${escapeXml(node.component_type||'group')}"`);
  const isLegacyMarker=node.component_type==='legacy-index-marker';
  const visible=isLegacyMarker ? settings.legacy_flower_markers?.visible===true : node.visible!==false;
  if (!visible) attrs.push('display="none"');
  let transform=node.layout_transform;
  if (node.layout_key==='wind_01_optical') {
    const dx=Number(settings.layout?.wind_01_optical_dx||0), dy=Number(settings.layout?.wind_01_optical_dy||0);
    transform=(dx||dy)?{type:'translate',x:dx,y:dy}:null;
  }
  if (node.layout_key==='center_flower_artwork_x' && settings.layout?.center_flower_artwork_horizontally===false) transform=null;
  if (transform?.type==='translate') {
    attrs.push(`transform="translate(${fmt(transform.x||0)} ${fmt(transform.y||0)})"`);
  }
  return `<g ${attrs.join(' ')}>${(node.children||[]).map(child=>renderNode(child,componentMap,settings)).join('\n')}</g>`;
}
function countNodes(node) {
  if (node.kind==='path') return {paths:1,groups:0};
  return (node.children||[]).reduce((a,n)=>{const c=countNodes(n);a.paths+=c.paths;a.groups+=c.groups;return a;},{paths:0,groups:1});
}
function svgForTile(tile, componentMap, settings) {
  const tree=renderNode(tile.root,componentMap,settings);
  const [x,y,w,h]=tile.viewBox;
  const title=escapeXml(tile.tile_id);
  return `<?xml version="1.0" encoding="UTF-8"?>\n`+
`<svg xmlns="http://www.w3.org/2000/svg" width="${fmt(w)}" height="${fmt(h)}" viewBox="${fmt(x)} ${fmt(y)} ${fmt(w)} ${fmt(h)}" role="img" aria-labelledby="title desc">\n`+
`<title id="title">${title}</title><desc id="desc">Self-contained vector tile generated from the absorbed asset library; source SVG not required at render time.</desc>\n`+
`${tree}\n</svg>\n`;
}
function walkGroups(node, out=[]) {
  if (node.kind==='group') {
    out.push({id:node.id,type:node.component_type,visible:node.visible!==false});
    for (const child of node.children||[]) walkGroups(child,out);
  }
  return out;
}
function createPreviewHtml(tiles, settings) {
  const columns=Math.max(2,Math.min(8,Number(settings.preview?.columns||6)));
  const bg=settings.preview?.card_background||'#fffdf7';
  const shadow=settings.preview?.card_shadow||'0 7px 16px rgba(38,31,24,.18)';
  const cards=tiles.map(t=>`<article class="tile-card" data-category="${t.category}">
  <div class="tile-image"><img loading="lazy" src="${t.file}" alt="${t.tile_id}"></div>
  <div class="tile-info"><strong>${t.tile_id}</strong><span>${t.display_name}</span><small>原始页 ${t.page} · ${t.path_count} 路径 · ${t.group_count} 组</small></div>
</article>`).join('\n');
  const cats=[...new Set(tiles.map(t=>t.category))];
  const opts=[['all','全部分类'],...cats.map(c=>[c,c])].map(([v,l])=>`<option value="${v}">${l}</option>`).join('');
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>American Mahjong · 吸收资产预览</title>
<style>
:root{color-scheme:light;--card:${bg};--shadow:${shadow}}*{box-sizing:border-box}body{margin:0;padding:24px;background:#f1efe9;color:#292723;font:15px/1.5 "Segoe UI",Arial,sans-serif}header{max-width:1600px;margin:0 auto 22px}h1{font-size:25px;margin:0 0 7px}.note{color:#655f56;margin:0 0 14px;max-width:1000px}.toolbar{display:flex;gap:12px;align-items:center;margin-bottom:18px}select{padding:8px 12px;border:1px solid #c9c3b8;border-radius:8px;background:#fff}.grid{max-width:1600px;margin:auto;display:grid;grid-template-columns:repeat(${columns},minmax(0,1fr));gap:18px}.tile-card{min-width:0}.tile-image{aspect-ratio:3/4;background:var(--card);border-radius:11px;box-shadow:var(--shadow);overflow:hidden}.tile-image img{width:100%;height:100%;display:block;object-fit:contain}.tile-info{display:flex;flex-direction:column;gap:2px;padding:7px 2px 0}.tile-info strong{font-size:13px}.tile-info span{font-size:12px;color:#5f594f}.tile-info small{font-size:11px;color:#8a8378}@media(max-width:1100px){.grid{grid-template-columns:repeat(4,minmax(0,1fr))}}@media(max-width:700px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
</style></head><body><header><h1>American Mahjong · 自包含矢量资产预览 v0.3</h1>
<p class="note">本预览由 library/asset_library.json 生成，不读取原始无底.svg。每张牌采用嵌套分组：tile → tile-outline / tile-content → 语义组件 → 可编辑路径实例。牌框默认线宽10；旧花牌序号已隐藏但仍保存在资产库中。</p>
<div class="toolbar"><label>分类：<select id="filter">${opts}</select></label><span>${tiles.length} 张基础牌 · 自包含资产库</span></div></header>
<main class="grid" id="grid">${cards}</main>
<script>document.getElementById('filter').addEventListener('change',function(){const v=this.value;document.querySelectorAll('.tile-card').forEach(e=>e.hidden=v!=='all'&&e.dataset.category!==v)})</script></body></html>`;
}
function main() {
  const settings=readJson('settings.json');
  const libPath=settings.library_file||'library/asset_library.json';
  const fullLib=path.resolve(ROOT,libPath);
  if (!fs.existsSync(fullLib)) throw new Error(`找不到已吸收资产库：${libPath}。先运行「01_首次吸收原始SVG.bat」。`);
  const library=JSON.parse(fs.readFileSync(fullLib,'utf8'));
  if (library.schema!=='american-mahjong-asset-library'||library.schema_version!=='0.3.0') throw new Error('资产库格式版本不匹配。');
  const componentMap=new Map(library.component_definitions.map(c=>[c.component_id,c]));
  const outRoot=path.resolve(ROOT,settings.output_dir||'output');
  ensureDir(outRoot);
  const rendered=[];
  for (const tile of library.tiles) {
    const relDir=path.join('tiles',tile.category);
    const filename=`${tile.tile_id}.svg`;
    const relFile=path.join(relDir,filename).replace(/\\/g,'/');
    const filePath=path.join(outRoot,relFile);
    ensureDir(path.dirname(filePath));
    fs.writeFileSync(filePath,svgForTile(tile,componentMap,settings),'utf8');
    const c=countNodes(tile.root);
    rendered.push({...tile,path_count:c.paths,group_count:c.groups,file:relFile,groups:walkGroups(tile.root)});
  }
  const tilesForPreview=rendered.map(({tile_id,category,display_name,page,path_count,group_count,file})=>({tile_id,category,display_name,page,path_count,group_count,file}));
  fs.writeFileSync(path.join(outRoot,'preview.html'),createPreviewHtml(tilesForPreview,settings),'utf8');
  const summary={schema_version:library.schema_version,library_file:path.relative(ROOT,fullLib),source_runtime_dependency:false,
    tile_count:rendered.length,component_geometry_count:library.component_definitions.length,
    shared_geometry_count:library.shared_geometry.length,legacy_flower_marker_paths:library.tiles.reduce((n,t)=>n+t.legacy_marker_count,0),
    tiles:rendered.map(t=>({tile_id:t.tile_id,page:t.page,category:t.category,path_count:t.path_count,group_count:t.group_count,file:t.file,groups:t.groups}))};
  fs.writeFileSync(path.join(outRoot,'render_manifest.json'),JSON.stringify(summary,null,2)+'\n','utf8');
  const report=`# 自包含资产渲染报告 v0.3\n\n- 牌面：${rendered.length}\n- 组件几何定义：${library.component_definitions.length}\n- 重复几何组：${library.shared_geometry.length}\n- 隐藏但保留的花牌旧序号路径：${summary.legacy_flower_marker_paths}\n- 原始 SVG 运行时依赖：无\n\n## 输出\n\n- preview.html：总览\n- render_manifest.json：嵌套分组结构\n- tiles/：42张独立SVG\n\n每张牌的 SVG 都从资产库 JSON 的 path geometry + instance transforms/styles 重建。\n`;
  fs.writeFileSync(path.join(outRoot,'RENDER_REPORT.md'),report,'utf8');
  console.log('渲染完成（未读取原始 SVG）。');
  console.log(`  牌面：${rendered.length}`);
  console.log(`  组件几何：${library.component_definitions.length}`);
  console.log(`  重复几何共享组：${library.shared_geometry.length}`);
  console.log(`  输出目录：${outRoot}`);
}
if (require.main===module) { try { main(); } catch(e) { console.error('\n渲染失败：'+e.message); process.exitCode=1; } }
module.exports={svgForTile,renderNode,countNodes,createPreviewHtml};
