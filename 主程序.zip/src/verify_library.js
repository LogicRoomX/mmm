'use strict';
const fs=require('fs');
const path=require('path');
const {ROOT,readJson}=require('./common');

function walk(node, out={paths:[],groups:[]}) {
  if (node.kind==='path') out.paths.push(node);
  else if (node.kind==='group') { out.groups.push(node); for (const c of node.children||[]) walk(c,out); }
  return out;
}
function main() {
  const settings=readJson('settings.json');
  const libFile=path.resolve(ROOT,settings.library_file||'library/asset_library.json');
  if (!fs.existsSync(libFile)) throw new Error('资产库不存在；请先执行首次吸收。');
  const lib=JSON.parse(fs.readFileSync(libFile,'utf8'));
  const errors=[];
  if (lib.schema!=='american-mahjong-asset-library') errors.push('schema 错误');
  if (lib.tiles?.length!==42) errors.push(`牌面数不是42：${lib.tiles?.length}`);
  if (lib.path_index?.length!==384) errors.push(`路径索引数不是384：${lib.path_index?.length}`);
  if (lib.source?.runtime_source_dependency!==false) errors.push('资产库仍声明依赖源 SVG');
  const ids=new Set(lib.component_definitions.map(x=>x.component_id));
  const allIds=new Set();
  let pathTotal=0, outlineTotal=0, markerTotal=0;
  for (const tile of lib.tiles||[]) {
    const flat=walk(tile.root);
    pathTotal+=flat.paths.length;
    const outlines=flat.paths.filter(p=>p.role==='tile-outline');
    outlineTotal+=outlines.length;
    if (outlines.length!==1) errors.push(`${tile.tile_id} 外轮廓数量不是1`);
    for (const p of flat.paths) {
      if (!ids.has(p.component_id)) errors.push(`${tile.tile_id}/${p.source_id} 缺少几何组件`);
      if (allIds.has(p.source_id)) errors.push(`源路径 ID 重复：${p.source_id}`);
      allIds.add(p.source_id);
    }
    const markers=flat.paths.filter(p=>p.role==='legacy-flower-index');
    markerTotal+=markers.length;
    const markerGroup=flat.groups.find(g=>g.id==='legacy-index-marker');
    if (tile.category==='flowers' && markers.length && !markerGroup) errors.push(`${tile.tile_id} 的旧花牌序号没有归档分组`);
    const outlineGroup=flat.groups.find(g=>g.id==='tile-outline');
    const contentGroup=flat.groups.find(g=>g.id==='tile-content');
    if (!outlineGroup||!contentGroup) errors.push(`${tile.tile_id} 缺少外框/内容分组`);
  }
  if (pathTotal!==384) errors.push(`树内路径总数错误：${pathTotal}`);
  if (outlineTotal!==42) errors.push(`外框总数错误：${outlineTotal}`);
  if (markerTotal!==8) errors.push(`花牌旧序号应识别8条，实际 ${markerTotal}`);
  if (errors.length) { console.error('验证失败：'); errors.forEach(x=>console.error(' - '+x)); process.exitCode=1; return; }
  console.log('资产库验证通过：');
  console.log(`  42 张牌 · ${pathTotal} 条路径实例 · ${ids.size} 个几何定义`);
  console.log(`  ${outlineTotal} 个独立外轮廓 · ${markerTotal} 条花牌旧序号已归档`);
  console.log('  运行时仅使用 asset_library.json，不依赖原始 SVG。');
}
if(require.main===module){try{main()}catch(e){console.error('验证失败：'+e.message);process.exitCode=1}}
module.exports={walk};
