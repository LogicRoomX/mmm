@echo off
setlocal EnableExtensions
chcp 65001 >nul
call "%~dp0\02_RENDER_FROM_LIBRARY.bat"
exit /b %ERRORLEVEL%
